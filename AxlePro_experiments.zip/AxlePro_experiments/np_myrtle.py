import math
import time
import numpy as np
import torch

import scipy
from sklearn.metrics import accuracy_score

from load_data import Load_Data
from save_data import Save_Data
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
torch.set_default_dtype(torch.float64)

print('start')
DATADIR = 'cifar-10-batches-py'

dataloader = Load_Data(DATADIR)

X, y = dataloader.loader(DATADIR)
KXX = np.load('NTK.npy')
KXX_test = KXX[50000: ,:50000]
KXX = KXX[:50000, :50000]
print('KXX.shape=', KXX.shape)
print('KXX_test.shape=', KXX_test.shape)

X_test, y_test = dataloader.loader(DATADIR, test=True)
y = y.numpy()
y_test = y_test.numpy()
for lam in [1e-5,1e-6,1e-7,1e-8]:#1e-3, 1e-4, 1e-5,1e-6,
    print('lam=', lam)
    KXX[np.diag_indices_from(KXX)] += lam
    alpha = np.linalg.solve(KXX, y)
    pred = np.matmul(KXX_test, alpha)
    idx = np.argmax(pred, axis=-1)
    pred = np.zeros(pred.shape)
    pred[np.arange(pred.shape[0]), idx] = 1
    acc = accuracy_score(y_test, pred)
    print('acc=', acc)