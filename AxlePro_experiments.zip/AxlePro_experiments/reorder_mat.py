import numpy as np

ind = np.array([['33', '34', '31', '35', '36', '32'],
                ['43', '44', '41', '45', '46', '42'],
                ['13', '14', '11', '15', '16', '12'],
                ['53', '54', '51', '55', '56', '52'],
                ['63', '64', '61', '65', '66', '62'],
                ['23', '24', '21', '25', '26', '22']])

NTK = np.zeros((60000, 60000))

for i in range(6):
    for j in range(6):
        mat_name = 'K' + str(i + 1) + str(j + 1) + '.npy'
        print('mat_name=', mat_name)
        block_mat = np.load(mat_name)
        NTK[i * 10000: (i + 1) * 10000, j * 10000: (j + 1) * 10000] = block_mat

np.save('NTK', NTK)

