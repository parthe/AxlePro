import math
import numpy as np
import random
import re
import pickle
import time
from matplotlib import pyplot as plt
from tqdm.auto import tqdm
import scipy
import torch
from plot import plot_graphs, save_data
from pytictoc import TicToc
# from torchkernels.kernels.radial import laplacian as KK
from torchkernels.kernels.radial import gaussian as K
from torchkernels.linalg.eigh import nystrom_extension
import os

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
torch.set_default_dtype(torch.float64)

timer = TicToc()

def nystrom_extension(K, X, Xs, E):
    """
        Extend eigenvectors
    """
    # E_ = K(X, Xs) @ E
    E_ = torch.zeros(X.shape[0], E.shape[1], device=X.device)
    iter_num = int(X.shape[0] / 20000)
    for i in range(iter_num):
        E_[i * 20000: (i + 1) * 20000, :] = K[i * 20000: (i + 1) * 20000, Xs] @ E
    if iter_num * 20000 < X.shape[0]:
        E_[iter_num * 20000:, :] = K[iter_num * 20000:, Xs] @ E
    return E_ / E_.norm(dim=0, keepdim=True)


def KmV(K, X, Z, v, out=None, row_chunk_size=20000, col_chunk_size=20000):
    """
        calculate kernel matrix vector product K(X, Z) @ v without storing kernel matrix
        If argument `out` is provided, the result is added to `out`
    """
    n_r, n_c = len(X), len(Z)
    b_r = n_r if row_chunk_size is None else row_chunk_size
    b_c = n_c if col_chunk_size is None else col_chunk_size
    return_flag = False
    if out is None:
        return_flag = True
        out = torch.zeros(n_r, *v.shape[1:], device=X.device)
    for i in range(math.ceil(n_r / b_r)):
        for j in range(math.ceil(n_c / b_c)):
            out[i * b_r:(i + 1) * b_r, :] += K(X[i * b_r:(i + 1) * b_r], Z[j * b_c:(j + 1) * b_c]) @ v[
                                                                                                     j * b_c:(
                                                                                                                     j + 1) * b_c,
                                                                                                     :]

    if return_flag: return out


# def generate_mse(a, KXX, X):
#     save_steps = len(a)
#     mse = torch.zeros(save_steps)
#     for i in range(save_steps):
#         mse[i] = (KXX @ a[i] - y).pow(2).mean()
#         # print('loss=', mse[i])
#     return mse


def top_eigen(KXX, X, q, scale):
    KXX = scale * KXX/len(X)  ###or use nystrom
    L, E = torch.lobpcg(KXX, q + 1)
    L = len(X)*L
    mu, eigvec = torch.lobpcg(KXX, 1, largest=False)
    mu = mu*len(X)
    beta = (KXX.diag() / scale - (E[:, :q].pow(2) * (L[:q] - L[q]) / scale).sum(-1)).max()
    return E[:, :q], L[:q], L[q], beta, mu


def top_eigen_eigh(KXX, X, q, scale):
    n = X.shape[0]
    KXX = scale * KXX#/len(X)  ###or use nystrom
    L, E = scipy.linalg.eigh(KXX.cpu().numpy(), subset_by_index=[n - q - 1, n - 1])
    L, E = torch.from_numpy(L).to(KXX.device).flipud(), torch.from_numpy(E).to(KXX.device).fliplr()
    mu = scipy.linalg.eigh(KXX.cpu().numpy(), eigvals_only=True, eigvals=(0, 0))
    mu = torch.from_numpy(mu).to(KXX.device).flipud()
    #L = len(X)*L
    #mu = len(X)*mu
    beta = (KXX.diag() / scale - (E[:, :q].pow(2) * (L[:q] - L[q]) / scale).sum(-1)).max()
    return E[:, :q], L[:q], L[q], beta, mu


def hyperparam_selection(m, n, L1, lqp1, lam_min):
    L = lqp1 / n
    mu = lam_min / n
    L_1 = L1
    kappa_tilde = n
    kappa_tilde_m = kappa_tilde / m + (m - 1) / m
    L_m = L_1 / m + (m - 1) * L / m
    kappa_m = L_m / mu
    eta_1 = 1 / L_m
    eta_2 = ((eta_1 * torch.sqrt(kappa_m * kappa_tilde_m)) / (torch.sqrt(kappa_m * kappa_tilde_m) + 1)) * (
            1 - 1 / kappa_tilde_m)
    gamma = (torch.sqrt(kappa_m * kappa_tilde_m) - 1) / (torch.sqrt(kappa_m * kappa_tilde_m) + 1)
    return eta_1, eta_2, gamma


def richardson_iteration(step_size, KXX, alpha, y, m):
    N = KXX.shape[0]
    myList = list(range(0, N))
    batch_ind = sorted(random.sample(myList, k=m))
    alpha[batch_ind, :] = alpha[batch_ind, :] - step_size * (
            torch.matmul(KXX[batch_ind, :], alpha) - y[batch_ind, :])
    return alpha


def precondition_kernel_matrix(q, KXX, nystrom=0):
    if nystrom:
        L, E = torch.lobpcg(KXX, q + 1)
        return L, E
    else:
        L, E = torch.lobpcg(KXX, q + 1)
        F = E[:, :q] * (L[:q] - L[-1]).sqrt()
        return KXX - F @ F.T, L, E, F


def MaSS_SGD(alpha, beta, eta1, gamma, eta2, K, y, m, N):
    # m: batch size
    # N: number of data points
    myList = list(range(0, N))
    batch_ind = sorted(random.sample(myList, k=m))
    alpha_new = beta * 1
    gm = 1 / m * (torch.matmul(K[batch_ind, :], beta) - y[batch_ind, :])
    alpha_new[batch_ind, :] = alpha_new[batch_ind, :] - eta1 * gm
    beta_new = alpha_new + gamma * (alpha_new - alpha)
    beta_new[batch_ind, :] = beta_new[batch_ind, :] + eta2 * gm
    return alpha_new, beta_new


def hyperparam_selection_Kp(L, mu, L_1, m, n):
    kappa_tilde = n
    kappa_tilde_m = kappa_tilde / m + (m - 1) / m
    L_m = L_1 / m + (m - 1) * L / m
    kappa_m = L_m / mu
    eta_1 = 1 / L_m
    eta_2 = ((eta_1 * torch.sqrt(kappa_m * kappa_tilde_m)) / (torch.sqrt(kappa_m * kappa_tilde_m) + 1)) * (
            1 - 1 / kappa_tilde_m)
    gamma = (torch.sqrt(kappa_m * kappa_tilde_m) - 1) / (torch.sqrt(kappa_m * kappa_tilde_m) + 1)
    return eta_1, eta_2, gamma, 1 - 1 / torch.sqrt(kappa_m * kappa_tilde_m), 1 - 1 / kappa_m


'''
def best_step_size(KXX, m):
    N = KXX.shape[0]
    eigvals = torch.linalg.eigvalsh(KXX/N)
    beta = KXX.diag().max()
    return 2/(beta + (m - 1) * eigvals[-1])
'''


def top_eigensystem(KXX, X, q, method='scipy.linalg.eigh'):
    assert method in {"scipy.linalg.eigh", "torch.lobpcg"}
    """
      Top-q eigen system of K(X, X)/n
      where n = len(X)

      Args: 
        K: kernel that takes 2 arguments.
        X: of shape (n, d).
        q: number of eigen-modes

      Returns:
        E: top-q eigenvectors
        L: top-q eigenvalues of
        lqp1: q+1 st eigenvalue
        beta: max{i} of K(xi, xi) - \sum_j=1^q (L[i]-lqp1) psi_j(xi)**2
    """

    n = X.shape[0]
    scaled_kmat = KXX / n
    if method == "scipy.linalg.eigh":
        L, E = scipy.linalg.eigh(scaled_kmat.cpu().numpy(), subset_by_index=[n - q - 1, n - 1])
        L, E = torch.from_numpy(L).to(scaled_kmat.device).flipud(), torch.from_numpy(E).to(scaled_kmat.device).fliplr()
    elif method == "torch.lobpcg":
        L, E = torch.lobpcg(scaled_kmat, q + 1)
    beta = n * (scaled_kmat.diag() - (E[:, :q].pow(2) * (L[:q] - L[q])).sum(-1)).max()

    return E[:, :q], L[:q], L[q], beta


def eigenpro(K, X, y, q, T, alpha_true=None, m=None, error=False, save_KXX=False, save_steps=100, nystrom=0,
             kernel=None):
    gap = T / save_steps
    n = X.shape[0]
    print('n=', n)
    nids = torch.randperm(n)[:nystrom]
    scale = 1#n / nystrom
    print('start')
    print(X[nids].shape)
    print('K shape = ', K.shape)
    a = torch.zeros_like(y, dtype=X.dtype, device=X.device)
    #if q > 0:
    E, L, lqp1, beta = top_eigensystem(K[nids][:, nids], X[nids], q)
    print(beta)
    L, lqp1 = scale * L, scale * lqp1
    E = nystrom_extension(K, X, nids, E)
    E, R = torch.linalg.qr(E)
    F = E * (1 - lqp1 / L).sqrt()
    bs_crit = int(beta / lqp1)

    if m is None: m = bs_crit
    lr = lambda bs: 1 / beta if bs < bs_crit else 2 / (beta + (bs - 1) * lqp1)
    #print(f"bs_crit={bs_crit}, m={m}, beta={beta}, l1={L[0] * n}, lqp1={lqp1 * n}, lr={lr(m)}")

    # print('eigenpro beta, lqp1, step size = ', beta, lqp1, lr(m))
    mse = [0] * (save_steps + 1)  # torch.zeros(save_steps + 1)
    mse[0] = a * 1  # (KmV(K, X, X, a) - y).pow(2).mean()
    save_count = 0

    param_error = torch.zeros(T + 1)
    start_time = time.time()
    # param_error[0] = ((alpha_true - a).T) @ KXX @ (alpha_true - a)
    print('T=', T)
    for t in tqdm(range(T)):
        for bids in torch.randperm(n).split(m):
            g = K[bids, :] @ a - y[bids, :]
            #g = g * 0.7
            a[bids, :] = a[bids, :] - lr(len(bids)) * g
            a += lr(len(bids)) * (F @ (F[bids].T @ g))
        if (t + 1) % gap == 0:
            save_count += 1
            mse[save_count] = a * 1  # (KmV(K, X, X, a) - y).pow(2).mean()
            # print('eigenpro save_count=', save_count)
            # param_error[t+1] = ((alpha_true - a).T) @ KXX @ (alpha_true - a)
    elapsed_time = time.time() - start_time

    return a, mse, param_error, elapsed_time


def PKmass_test(K, X, y, T, m, q, alpha_true=None, alpha=None, save_KXX=False, save_steps=100, nystrom=0):
    gap = T / save_steps
    n = X.shape[0]
    nids = torch.randperm(n)[:nystrom]
    scale = 1#n / nystrom
    # E, L, lqp1, beta, mu = top_eigen(K, X[nids], q, scale)
    E, L, lqp1, beta, mu = top_eigen_eigh(K[nids][:, nids], X[nids], q, scale)
    print(mu)

    mu = mu*0.5 # tune mu
    E = nystrom_extension(K, X, nids, E)
    E, R = torch.linalg.qr(E)
    F = E * (1 - lqp1 / L).sqrt()
    print(beta)
    #beta=1 ###set beta=1
    bs_crit = int(beta / lqp1) + 1
    if m is None: m = bs_crit
    eta1, eta2, gamma = hyperparam_selection(m, n, beta, lqp1, mu)
    eta1, eta2 = eta1 / m, eta2 / m
    print('PMASS eta1, eta2, gamma:', eta1, eta2, gamma)
    print('beta=', beta)
    # alpha_true =1
    if alpha is None:
        b, a = torch.zeros_like(y, dtype=X.dtype, device=X.device), torch.zeros_like(y, dtype=X.dtype, device=X.device)
    else:
        a = (E * 1 / L) @ (E.T @ y)
        b = a * 1
    mse = [0] * (save_steps + 1)  # torch.zeros(save_steps + 1)
    mse[0] = a * 1  # (KmV(K, X, X, a) - y).pow(2).mean()
    save_count = 0
    Pmass_param_error = torch.zeros(T + 1, device=X.device)
    # Pmass_param_error[0] = ((alpha_true - a).T) @ KXX @ (alpha_true - a)
    myList = list(range(0, n))

    start_time = time.time()
    print('m=', m)
    print('F shape=', F.shape)
    for t in tqdm(range(T)):
        for bids in torch.randperm(n).split(m):
            #bids = sorted(random.sample(myList, k=m))
            gm = K[bids, :] @ b - y[bids]
            # #h = F @ (F[bids].T @ gm)
            x = F[bids].T @ gm
            h = F @ x
            a_ = a.clone()
            #a = b + eta1 * h
            a=b.clone()
            a+= eta1*h
            a[bids, :] -= eta1 * gm
            #b = a + gamma * (a - a_) - eta2 * h
            b = a + gamma * (a - a_)
            b -= eta2*h
            b[bids, :] += eta2 * gm
        
        if (t + 1) % gap == 0:
            save_count += 1
            mse[save_count] = a * 1  # (KmV(K, X, X, a) - y).pow(2).mean()
        # Pmass_param_error[t+1] = (((alpha_true - a).T) @ KXX @ (alpha_true - a))
    elapsed_time = time.time() - start_time
    return a, mse, Pmass_param_error, elapsed_time





def generate_mse(a, KXX, y, pri=False):
    T = len(a)
    mse = torch.zeros(T)
    for i in tqdm(range(T)):
        mse[i] = (KXX @ a[i] - y).pow(2).mean()
    return mse

'''
sgd, mass, psgd, pmass comparison
n = 1000
d = 10
m = 300
T = 20000
t = np.arange(T + 1) + 1
X = torch.rand(n, d)
KXX = K(X, X)
alpha = torch.rand(n, 1)
y = KXX @ alpha
alpha_initial = 100 * torch.rand(n, 1)
q = 0
a, MSE_Eigenpro, Eigenpro_param_error = eigenpro(KXX, X, y, q, T, m=m, error=True, nystrom=n,
                                                 save_steps=T, save_KXX=True)
MSE_SGD = generate_mse(MSE_Eigenpro, KXX, y)
a, MSE_Pmass, Pmass_param_error = PKmass_test(KXX, X, y, T, m, q, nystrom=n, save_steps=T,
                                              save_KXX=True)
MSE_MASS = generate_mse(MSE_Pmass, KXX, y)

q = 20
a, MSE_Eigenpro, Eigenpro_param_error = eigenpro(KXX, X, y, q, T, m=m, error=True, nystrom=n,
                                                 save_steps=T, save_KXX=True)
MSE_PSGD = generate_mse(MSE_Eigenpro, KXX, y)
a, MSE_Pmass, Pmass_param_error = PKmass_test(KXX, X, y, T, m, q, nystrom=n, save_steps=T,
                                              save_KXX=True)
MSE_PMASS = generate_mse(MSE_Pmass, KXX, y)

plt.plot(t, MSE_SGD, label='SGD')
plt.plot(t, MSE_MASS, label='MaSS')
plt.plot(t, MSE_PSGD, label='EigenPro', color='blue')
plt.plot(t, MSE_PMASS, label='AxlePro', color='green')
plt.yscale('log')
plt.legend()
plt.show()'''
def eigenpro2(K, X, y, q, T, alpha_true=None, m=None, error=False, save_KXX=False, save_steps=100, nystrom=0,
             kernel=None):
    gap = T / save_steps
    n = X.shape[0]

    print('n=', n)
    nids = torch.randperm(n)[:nystrom]
    print('start')
    print(X[nids].shape)
    #print('K shape = ', K.shape)
    a = torch.zeros_like(y, dtype=X.dtype, device=X.device)
    #if q > 0:
    D, L, lqp1, beta = top_eigensystem(K[nids][:, nids], X[nids], q)
    #beta=1
    print(beta)
    #L, lqp1 = scale * L, scale * lqp1
    #E = nystrom_extension(K, X, nids, E)
    #E, R = torch.linalg.qr(E)
    G = D * ((1 - lqp1 / L)/(L*nystrom)).sqrt()
    bs_crit = int(beta / lqp1)

    if m is None: m = bs_crit
    lr = lambda bs: 1 / beta if bs < bs_crit else 2 / (beta + (bs - 1) * lqp1)
    print(f"bs_crit={bs_crit}, m={m}, beta={beta}, l1={L[0] * n}, lqp1={lqp1 * n}, lr={lr(m)}")

    print('eigenpro beta, lqp1, step size = ', beta, lqp1, lr(m))
    mse = [0] * (save_steps + 1)  # torch.zeros(save_steps + 1)
    mse[0] = a * 1  # (KmV(K, X, X, a) - y).pow(2).mean()
    save_count = 0
    Knids = K[nids]
    myList = list(range(0, n))
    param_error = torch.zeros(T + 1)
    start_time = time.time()

    # param_error[0] = ((alpha_true - a).T) @ KXX @ (alpha_true - a)
    for t in tqdm(range(T)):
        for bids in torch.randperm(n).split(m):
            v = K[bids, :] @ a - y[bids]
            #g = g * 0.7
            w = G@(G.T@ (Knids[:, bids]@v))
            #print('w[0]', w[0])
            a[bids, :] = a[bids, :] - lr(len(bids)) * v
            a[nids, :] +=  lr(len(bids)) * w
        if (t + 1) % gap == 0:
            save_count += 1
            mse[save_count] = a * 1  # (KmV(K, X, X, a) - y).pow(2).mean()
            # print('eigenpro save_count=', save_count)
            # param_error[t+1] = ((alpha_true - a).T) @ KXX @ (alpha_true - a)
    elapsed_time = time.time() - start_time

    return a, mse, param_error, elapsed_time

def PKmass_test_nystrom(K, X, y, T, m, q, alpha_true=None, alpha=None, save_KXX=False, save_steps=100, nystrom=0):
    gap = T / save_steps
    n = X.shape[0]
    nids = torch.randperm(n)[:nystrom]
    scale =1# n / nystrom
    # E, L, lqp1, beta, mu = top_eigen(K, X[nids], q, scale)
    E, L, lqp1, beta, mu = top_eigen_eigh(K[nids][:, nids], X[nids], q, scale)
    print(mu)

    mu = mu*0.5 # tune mu
    #E = nystrom_extension(K, X, nids, E)
    #E, R = torch.linalg.qr(E)
    G = E * ((1 - lqp1 / L)/(L)).sqrt()
    print(beta)
    bs_crit = int(beta / lqp1) + 1
    if m is None: m = bs_crit
    eta1, eta2, gamma = hyperparam_selection(m, n, beta, lqp1, mu)
    eta1, eta2 = eta1 / m, eta2 / m
    print('PMASS eta1, eta2, gamma:', eta1, eta2, gamma)
    print('beta=', beta)
    #beta=1
    # alpha_true =1
    if alpha is None:
        b, a = torch.zeros_like(y, dtype=X.dtype, device=X.device), torch.zeros_like(y, dtype=X.dtype, device=X.device)
    else:
        a = (E * 1 / L) @ (E.T @ y)
        b = a * 1
    mse = [0] * (save_steps + 1)  # torch.zeros(save_steps + 1)
    mse[0] = a * 1  # (KmV(K, X, X, a) - y).pow(2).mean()
    save_count = 0
    Pmass_param_error = torch.zeros(T + 1, device=X.device)
    # Pmass_param_error[0] = ((alpha_true - a).T) @ KXX @ (alpha_true - a)
    K_nids = K[nids]#K(X[nids], X)
    myList = list(range(0, n))
    t_LMAP = []
    temp = torch.randn(nystrom, m)

    start_time = time.time()
    print('m=', m)
    print('G shape=', G.shape)

        
    for t in tqdm(range(T)):
        for bids in torch.randperm(n).split(m):
            gm = K[bids, :] @ b - y[bids] #v
            # #h = F @ (F[bids].T @ gm)
            # #h = G @ (G.T @ (K[nids][:, bids] @ gm)) #w
            x = K_nids[:, bids] @ gm #temp@gm#
            x = G.T @ x
            h = G @ x
            a_ = a.clone()
            a=b.clone()
            a[nids, :] += eta1 * h
            a[bids, :] -= eta1 * gm
            b = a + gamma * (a - a_)

            b[bids, :] += eta2 * gm
            b[nids, :] -= eta2 * h
        
        if (t + 1) % gap == 0:
            save_count += 1
            mse[save_count] = a * 1  # (KmV(K, X, X, a) - y).pow(2).mean()
        # Pmass_param_error[t+1] = (((alpha_true - a).T) @ KXX @ (alpha_true - a))
    elapsed_time = time.time() - start_time
    return a, mse, Pmass_param_error, elapsed_time

n = 20000
d = 10
m = 50#500
q = 20
n, m, s, q = 20000, 100, 600, 200
#n, m, s, q = 2**15, 2**8, 2**11, 2**7
T = 120
t = np.arange(T + 1) + 1
X = torch.rand(n, d)
#X = X.to('cuda')
X = X/X.norm(dim=-1, keepdim=True)
KXX = K(X, X, bandwidth=0.1)
steps = np.linspace(0, T, num=21)
alpha = torch.rand(n, 1)
#alpha = alpha.to('cuda')
y = KXX @ alpha
print(y.norm)


#compare with extended nystrom
a, MSE_Eiegenpro, e_error, elapsed_time_extended_eg = eigenpro(KXX, X, y, q, T, m=m, nystrom=s, save_steps=20,
                                              save_KXX=True)
print('time=', elapsed_time_extended_eg)
pmass_time_extended = np.linspace(0, elapsed_time_extended_eg, num=21)
MSE_eigenpro_nystrom_extended = generate_mse(MSE_Eiegenpro, KXX, y, pri=True)

a, MSE_Eigenpro2, p_e, elapsed_time_eg = eigenpro2(KXX, X, y, q, T, m=m, nystrom=s, save_steps=20,
                                              save_KXX=True)
print('time=', elapsed_time_eg)
pmass_time = np.linspace(0, elapsed_time_eg, num=21)
MSE_eigenpro2_nystrom = generate_mse(MSE_Eigenpro2, KXX, y)



a, MSE_Pmass, Pmass_param_error, elapsed_time = PKmass_test_nystrom(KXX, X, y, T, m, q, nystrom=s, save_steps=20,
                                              save_KXX=True)
print('time=', elapsed_time)
pmass_time = np.linspace(0, elapsed_time, num=21)
MSE_PMASS_nystrom = generate_mse(MSE_Pmass, KXX, y)


a, MSE_Pmass, Pmass_param_error, elapsed_time_extended = PKmass_test(KXX, X, y, T, m, q, nystrom=s, save_steps=20,
                                              save_KXX=True)
print('time=', elapsed_time_extended)
pmass_time_extended = np.linspace(0, elapsed_time_extended, num=21)
MSE_PMASS_nystrom_extended = generate_mse(MSE_Pmass, KXX, y)



plt.plot(steps, MSE_PMASS_nystrom_extended, label='AxlePro', color='red')
plt.plot(steps, MSE_PMASS_nystrom, label='LM-AxlePro', color='blue')
plt.plot(steps, MSE_eigenpro_nystrom_extended, label='EigenPro', color='green')
plt.plot(steps, MSE_eigenpro2_nystrom, label='EigenPro2', color='orange')
plt.yscale('log')
plt.xlabel('Epochs')
plt.ylabel('MSE')

plt.legend()
plt.show()
plt.savefig('new_nystrom_compare_step.png')
plt.clf()



plt.plot(pmass_time_extended, MSE_PMASS_nystrom_extended, label='AxlePro', color='red')
plt.plot(pmass_time, MSE_PMASS_nystrom, label='LM-AxlePro', color='blue')
plt.plot(pmass_time_extended, MSE_eigenpro_nystrom_extended, label='EigenPro', color='green')
plt.plot(pmass_time, MSE_eigenpro2_nystrom, label='EigenPro2', color='orange')

min_time = min(elapsed_time, elapsed_time_extended, elapsed_time_eg, elapsed_time_extended_eg)
plt.xlim(0, min_time)

plt.yscale('log')
plt.xlabel('Time (s)')
plt.ylabel('MSE')

plt.legend()
plt.show()
plt.savefig('new_nystrom_compare_time.png')

plt.clf()
plt.plot(1+pmass_time_extended, MSE_PMASS_nystrom_extended, label='AxlePro', color='red')
plt.plot(1+pmass_time, MSE_PMASS_nystrom, label='LM-AxlePro', color='blue')
plt.plot(1+pmass_time_extended, MSE_eigenpro_nystrom_extended, label='EigenPro', color='green')
plt.plot(1+pmass_time, MSE_eigenpro2_nystrom, label='EigenPro2', color='orange')

min_time = 1+min(elapsed_time, elapsed_time_extended, elapsed_time_eg, elapsed_time_extended_eg)
plt.xlim(1, min_time)

plt.yscale('log')
plt.xscale('log')
plt.xlabel('Time (s)')
plt.ylabel('MSE')

plt.legend()
plt.show()
plt.savefig('new_nystrom_compare_time_logx.png')
