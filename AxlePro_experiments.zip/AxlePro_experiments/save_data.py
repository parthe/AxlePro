import pickle


class Save_Data():
    data_name = None
    def __init__(self, DATADIR):
        match DATADIR:
            case 'cifar-10-batches-py':
                self.data_name = 'cifar'
            case 'SUSY.csv':
                self.data_name = 'susy' 
            case 'star_classification.csv':
                self.data_name = 'star'
            case 'emnist-digits-train.csv':
                self.data_name = 'emnist'
            case 'YearPrediction.txt':
                self.data_name = 'yearpred'                
        self.data_name = self.data_name + '_LMAP'

    def save_data(self, alg, dict):
        try:
            with open(self.data_name, 'rb') as file:
                data = pickle.load(file)
                print(f"Loading {self.data_name} ")
                data[alg] = dict
            with open(self.data_name, 'wb') as file:
                pickle.dump(data, file)

        except FileNotFoundError:
            with open(self.data_name, 'wb') as file:
                new_dict = {alg: dict}
                pickle.dump(new_dict, file)
                print(f"Created {self.data_name} and saved data")

    @staticmethod
    def dict_generator(steps, time, setup_time, MSE, class_err, test_mse, test_class_err,test_mse_all, test_class_err_all):
        dict = {'steps': steps, 'time': time, 'setup_time': setup_time, 'MSE': MSE,
                'class_err': class_err, 'test_mse': test_mse, 'test_class_err': test_class_err, 'test_mse_all':test_mse_all, 'test_class_err_all':test_class_err_all}
        return dict