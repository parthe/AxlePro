import pickle
import torch
import numpy as np
from matplotlib import pyplot as plt

def save_data(file_name, dict):
    try:
        with open(file_name, 'rb') as file:
            data = pickle.load(file)
            print(f"Loading {file_name} ")
            data.update(dict)
        with open(file_name, 'wb') as file:
            pickle.dump(data, file)

    except FileNotFoundError:
        with open(file_name, 'wb') as file:
            pickle.dump(dict, file)
            print(f"Created {file_name} and saved data：")

def plot_graphs(filename, nystrom=0):
    if nystrom:
        with open(filename, 'rb') as fp:
            data = pickle.load(fp)

        plt.plot(1 + data['t_cg'], data['CG_MSE'], label='CG')
        plt.plot(1 + data['t'], data['MSE_Pmass'], label='PMASS', color='r')
        #    plt.plot(1+data['t'], data['MSE_Pmass_ini'], label='PMASS init', color='b')
        #plt.plot(1 + data['t'], data['error_Kp_MaSS_SGD'], label='PMASS Kp', color='k')
        #    plt.plot(1+data['t'], data['error_Kp_MaSS_SGD_ini'], label='PMASS Kp init')
        #plt.plot(1 + data['t'], data['error_Kp_sgd'], label='PSGD Kp')
        plt.plot(1 + data['t'], data['MSE_Eigenpro'], label='Eigenpro')

        plt.yscale('log')
        #plt.xscale('log')

        plt.xlabel('Steps')
        plt.ylabel('MSE (train)')
        plt.title('Comparison of convergence with Nystrom extension')
        plt.legend()
        plt.show()
        plt.savefig('Loss_curve.png')
        plt.clf()

        save_steps = data['t'].shape[0]

        eigenpro_time = data['eigenpro_time'] - data['setup_time'][0]
        #    Pmass_ini_time = data['Pmass_ini_time'] - data['setup_time'][0] - data['setup_time'][1]
        Pmass_time = data['Pmass_time'] - data['setup_time'][0] - data['setup_time'][1]
        #eigenpro_kp_time = data['eigenpro_kp_time'] - data['setup_time'][0]
        #Kpmass_time = data['Kpmass_time'] - data['setup_time'][0] - data['setup_time'][1]
        #    Kpmass_ini_time = data['Kpmass_ini_time'] - data['setup_time'][0] - data['setup_time'][1]

        cg_time = np.linspace(0, data['cg_time'], num=save_steps)
        eigenpro_time = np.linspace(0, eigenpro_time, num=save_steps)
        #    Pmass_ini_time = np.linspace(0, Pmass_ini_time, num=save_steps)
        Pmass_time = np.linspace(0, Pmass_time, num=save_steps)
        #eigenpro_kp_time = np.linspace(0, eigenpro_kp_time, num=save_steps)
        #Kpmass_time = np.linspace(0, Kpmass_time, num=save_steps)
        #    Kpmass_ini_time = np.linspace(0, Kpmass_ini_time, num=save_steps)

        plt.plot(1 + cg_time, data['CG_MSE'], label='CG')
        plt.plot(1 + Pmass_time, data['MSE_Pmass'], label='PMASS', color='r')
        #    plt.plot(1+Pmass_ini_time, data['MSE_Pmass_ini'], label='PMASS init', color='b')
        plt.plot(1 + eigenpro_time, data['MSE_Eigenpro'], label='Eigenpro')
        #plt.plot(1 + Kpmass_time, data['error_Kp_MaSS_SGD'], label='PMASS Kp', color='k')
        #    plt.plot(1+Kpmass_ini_time, data['error_Kp_MaSS_SGD_ini'], label='PMASS Kp init')
        #plt.plot(1 + eigenpro_kp_time, data['error_Kp_sgd'], label='PSGD Kp')

        min_time = min([Pmass_time[-1], eigenpro_time[-1], cg_time[-1]])  #
        plt.yscale('log')
        #plt.xscale('log')
        plt.xlim(0, min_time)
        plt.xlabel('Time')
        plt.ylabel('MSE (train)')
        plt.title('Comparison of convergence with Nystrom extension')
        plt.legend()
        plt.show()

        plt.savefig('Loss_curve_time.png')
        print('setup time for eigenpro is ', data['setup_time'][0])
        print('setup time for PMASS is ', data['setup_time'][0] + data['setup_time'][1])
    else:
        with open(filename, 'rb') as fp:
            data = pickle.load(fp)

        plt.plot(1+data['t_cg'], data['CG_MSE'], label='CG')
        plt.plot(1+data['t'], data['MSE_Pmass'], label='PMASS', color='r')
    #    plt.plot(1+data['t'], data['MSE_Pmass_ini'], label='PMASS init', color='b')
        plt.plot(1+data['t'], data['error_Kp_MaSS_SGD'], label='PMASS Kp', color='k')
    #    plt.plot(1+data['t'], data['error_Kp_MaSS_SGD_ini'], label='PMASS Kp init')
        plt.plot(1+data['t'], data['error_Kp_sgd'], label='PSGD Kp')
        plt.plot(1+data['t'], data['MSE_Eigenpro'], label='Eigenpro')

        plt.yscale('log')
        plt.xscale('log')

        plt.xlabel('Steps')
        plt.ylabel('MSE (train)')
        if data['save_KXX']:
            plt.title('Comparison of convergence when the kernel matrix is saved')
        else:
            plt.title('Comparison of convergence when the kernel matrix is not saved')
        plt.legend()
        plt.show()
        plt.savefig('Loss_curve.png')
        plt.clf()

        save_steps = data['t'].shape[0]

        eigenpro_time = data['eigenpro_time'] - data['setup_time'][0]
    #    Pmass_ini_time = data['Pmass_ini_time'] - data['setup_time'][0] - data['setup_time'][1]
        Pmass_time = data['Pmass_time'] - data['setup_time'][0] - data['setup_time'][1]
        eigenpro_kp_time = data['eigenpro_kp_time'] - data['setup_time'][0]
        Kpmass_time = data['Kpmass_time'] - data['setup_time'][0] - data['setup_time'][1]
    #    Kpmass_ini_time = data['Kpmass_ini_time'] - data['setup_time'][0] - data['setup_time'][1]

        cg_time = np.linspace(0, data['cg_time'], num=save_steps)
        eigenpro_time = np.linspace(0, eigenpro_time, num=save_steps)
    #    Pmass_ini_time = np.linspace(0, Pmass_ini_time, num=save_steps)
        Pmass_time = np.linspace(0, Pmass_time, num=save_steps)
        eigenpro_kp_time = np.linspace(0, eigenpro_kp_time, num=save_steps)
        Kpmass_time = np.linspace(0, Kpmass_time, num=save_steps)
    #    Kpmass_ini_time = np.linspace(0, Kpmass_ini_time, num=save_steps)

        plt.plot(1+cg_time, data['CG_MSE'], label='CG')
        plt.plot(1+Pmass_time, data['MSE_Pmass'], label='PMASS', color='r')
    #    plt.plot(1+Pmass_ini_time, data['MSE_Pmass_ini'], label='PMASS init', color='b')
        plt.plot(1+eigenpro_time, data['MSE_Eigenpro'], label='Eigenpro')
        plt.plot(1+Kpmass_time, data['error_Kp_MaSS_SGD'], label='PMASS Kp', color='k')
    #    plt.plot(1+Kpmass_ini_time, data['error_Kp_MaSS_SGD_ini'], label='PMASS Kp init')
        plt.plot(1+eigenpro_kp_time, data['error_Kp_sgd'], label='PSGD Kp')

        min_time = min([Pmass_time[-1], eigenpro_time[-1], Kpmass_time[-1],
                        eigenpro_kp_time[-1], cg_time[-1]])  #
        plt.yscale('log')
        plt.xscale('log')
        plt.xlim(0, min_time)
        plt.xlabel('Time')
        plt.ylabel('MSE (train)')
        if data['save_KXX']:
            plt.title('Comparison of convergence when the kernel matrix is saved')
        else:
            plt.title('Comparison of convergence when the kernel matrix is not saved')
        plt.legend()
        plt.show()

        plt.savefig('Loss_curve_time.png')
        print('setup time for eigenpro is ', data['setup_time'][0])
        print('setup time for PMASS is ', data['setup_time'][0] + data['setup_time'][1])

#plot_graphs('data_nystrom_full_cifar.pkl', nystrom=20000)