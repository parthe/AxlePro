from torchkernels.kernels.radial import gaussian as K

import torchvision
import os
import math
import numpy as np
import torch
from tqdm.auto import tqdm

from load_data import Load_Data
import os

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
torch.set_default_dtype(torch.float64)


def KmV(K, X, Z, v, out=None, row_chunk_size=20000, col_chunk_size=20000):
    """
        calculate kernel matrix vector product K(X, Z) @ v without storing kernel matrix
        If argument `out` is provided, the result is added to `out`
    """
    n_r, n_c = len(X), len(Z)
    b_r = n_r if row_chunk_size is None else row_chunk_size
    b_c = n_c if col_chunk_size is None else col_chunk_size
    return_flag = False
    if out is None:
        return_flag = True
        out = torch.zeros(n_r, *v.shape[1:], device=X.device)
    for i in range(math.ceil(n_r / b_r)):
        for j in range(math.ceil(n_c / b_c)):
            out[i * b_r:(i + 1) * b_r, :] += K(X[i * b_r:(i + 1) * b_r], Z[j * b_c:(j + 1) * b_c]) @ v[ j * b_c:(j + 1) * b_c,:]

    if return_flag: return out


def FALKON(X, Y, lev_scores, M, KernelMatrix, lambda_val, t, save_steps=100, save_KXX=False, kernel=None):
    n = X.size(0)
    if save_KXX == True:
        if kernel !=None:
            print(kernel)
            KXX = KernelMatrix
        else:
            KXX = KernelMatrix(X, X)
    
    C, D, indices = selectNystromCenters(X, lev_scores, M, n)
    if save_KXX == False:
        KMM = KernelMatrix(C, C)
    else:
        KMM = KernelMatrix[indices][:, indices]
    eps = torch.finfo(torch.float).eps
    T = torch.linalg.cholesky(D @ KMM @ D.t() + eps * M * torch.eye(M, device=X.device), upper=True)
    A = torch.linalg.cholesky(T @ T.t() / M + lambda_val * torch.eye(M, device=X.device), upper=True)

    def KnMtimesVector(u, v):
        c = max(v.shape[-1], u.shape[-1])
        w = torch.zeros(M, c, device=u.device)
        ms = np.ceil(np.linspace(0, n, int(np.ceil(n / M) + 1)))
        for i in range(1, math.ceil(n / M) + 1):
            if save_KXX:
                Kr = KXX[int(ms[i - 1]): int(ms[i]), indices]
            else:
                Kr = KernelMatrix(X[int(ms[i - 1]): int(ms[i]), :], C)
            w += Kr.t() @ ((Kr @ u) + v[int(ms[i - 1]):int(ms[i]), :])
        return w

    def BHB(u):
        return torch.linalg.solve(A.t(), torch.linalg.solve(T.t(), KnMtimesVector(
            torch.linalg.solve(T, torch.linalg.solve(A, u)), torch.zeros(n, 1).to(u.device)) / n)
                                  + lambda_val * torch.linalg.solve(A, u))

    r = torch.linalg.solve(A.t(), torch.linalg.solve(T.t(), KnMtimesVector(torch.zeros(M, 1, device=X.device), Y / n)))
    beta, mse = conjgrad(BHB, r, t, T, A, save_steps=save_steps)
    alpha = torch.linalg.solve(T, torch.linalg.solve(A, beta))
    return alpha, indices, mse


def conjgrad(funA, r, tmax, T, A, save_steps=100):
    p = r.clone()
    rsold = r.pow(2).sum(0)
    beta = torch.zeros_like(r)
    mse = [0] * (save_steps + 1)
    mse[0] = torch.linalg.solve(T, torch.linalg.solve(A, beta)) * 1
    save_count = 0
    for i in tqdm(range(tmax)):
        Ap = funA(p)
        a = rsold / (p * Ap).sum(0)
        beta += a * p
        r -= a * Ap
        rsnew = r.pow(2).sum(0)
        p = r + (rsnew / rsold) * p
        rsold = rsnew
        if (i + 1) % (tmax / save_steps) == 0:
            save_count += 1
            mse[save_count] = torch.linalg.solve(T, torch.linalg.solve(A, beta)) * 1
    return beta, mse


def selectNystromCenters(X, lev_scores, M, n):
    if lev_scores is None:  # Uniform Nystrom
        D = torch.eye(M, device=X.device)
        indices = torch.randperm(n, device=X.device)[:M]
        C = X[indices, :]
    else:  # Approximate Lev. Scores Nystrom
        prob = lev_scores / torch.sum(lev_scores)
        count, ind = discrete_prob_sample(M, prob)

        D = torch.diag(1.0 / torch.sqrt(n * prob[ind] * count))
        C = X[ind, :]

    return C, D, indices


def discrete_prob_sample(M, prob):
    rand_samples = np.random.rand(M)
    edges = np.cumsum(prob)
    hist, _ = np.histogram(rand_samples, bins=np.append(0, edges))
    ind = np.where(hist > 0)[0]
    count = hist[ind]
    return torch.tensor(count), ind


def generate_mse_test(a, K, X, X_test, y, indices=None, loss='mse', save_KXX=False, KXX_test=None):
    save_steps = len(a)
    mse = torch.zeros(save_steps)
    if loss == 'mse':
        for i in tqdm(range(save_steps)):
            if indices == None:
                mse[i] = (KmV(K, X, X, a[i]) - y).pow(2).mean()
            else:
                alpha = torch.zeros_like(y, device=y.device)
                alpha[indices, :] = a[i]
                mse[i] = (KmV(K, X, X, alpha) - y).pow(2).mean()
    elif loss == 'class':
        for i in tqdm(range(save_steps)):
            true_label = torch.argmax(y, dim=1)
            if indices == None:
                pred = KmV(K, X, X, a[i])
                max_indices = torch.argmax(pred, dim=1)
                zero_mask = (abs(max_indices - true_label) == 0)
                num_zeros = torch.sum(zero_mask).item()
                mse[i] = num_zeros / y.shape[0]
            else:
                alpha = torch.zeros_like(y, device=y.device)
                alpha[indices, :] = a[i]
                pred = KmV(K, X, X, alpha)
                max_indices = torch.argmax(pred, dim=1)
                zero_mask = (abs(max_indices - true_label) == 0)
                num_zeros = torch.sum(zero_mask).item()
                mse[i] = num_zeros / y.shape[0]
    elif loss == 'both':
        class_err = torch.zeros(save_steps)
        true_label = torch.argmax(y, dim=1)
        for i in tqdm(range(save_steps)):
            if indices == None:
                if save_KXX==False:
                    pred = KmV(K, X_test, X, a[i])
                else:
                    pred = X_test @ a[i]
                if y.shape[1] == 1:
                    pred_label = (pred >= 0.5).int()
                    num_wrong = torch.sum(abs(pred_label - y))
                    class_err[i] = 1 - (num_wrong / y.shape[0])
                else:
                    max_indices = torch.argmax(pred, dim=1)
                    zero_mask = (abs(max_indices - true_label) == 0)
                    num_zeros = torch.sum(zero_mask).item()
                    class_err[i] = num_zeros / y.shape[0]
                    print('max_indices and true_label', max_indices, true_label)
                #print('pred and y = ', pred, y)
                mse[i] = (pred - y).pow(2).mean()
            else:
                #alpha = torch.zeros_like(y, device=y.device)
                alpha = torch.zeros(X.shape[0], y.shape[1], device=y.device)
                alpha[indices, :] = a[i]
                if save_KXX==False:
                    pred = KmV(K, X_test, X, alpha)
                else:
                    pred = X_test @ alpha
                if y.shape[1] == 1:
                    pred_label = (pred >= 0.5).int()
                    num_wrong = torch.sum(abs(pred_label - y))
                    class_err[i] = 1 - (num_wrong / y.shape[0])
                else:
                    max_indices = torch.argmax(pred, dim=1)
                    
                    zero_mask = (abs(max_indices - true_label) == 0)
                    num_zeros = torch.sum(zero_mask).item()
                    class_err[i] = num_zeros / y.shape[0]
                mse[i] = (pred - y).pow(2).mean()
        #print('num_zeros , y.shape[0]=', num_zeros, y.shape[0])
        return mse, class_err
    return mse


def generate_mse(a, K, X, y, indices=None, loss='mse', save_KXX=False):
    save_steps = len(a)
    mse = torch.zeros(save_steps)
    if loss == 'mse':
        for i in tqdm(range(save_steps)):
            if indices == None:
                mse[i] = (KmV(K, X, X, a[i]) - y).pow(2).mean()
            else:
                alpha = torch.zeros_like(y, device=y.device)
                alpha[indices, :] = a[i]
                mse[i] = (KmV(K, X, X, alpha) - y).pow(2).mean()
    elif loss == 'class':
        for i in tqdm(range(save_steps)):
            true_label = torch.argmax(y, dim=1)
            if indices == None:
                pred = KmV(K, X, X, a[i])
                max_indices = torch.argmax(pred, dim=1)
                zero_mask = (abs(max_indices - true_label) == 0)
                num_zeros = torch.sum(zero_mask).item()
                mse[i] = num_zeros / y.shape[0]
            else:
                alpha = torch.zeros_like(y, device=y.device)
                alpha[indices, :] = a[i]
                pred = KmV(K, X, X, alpha)
                max_indices = torch.argmax(pred, dim=1)
                zero_mask = (abs(max_indices - true_label) == 0)
                num_zeros = torch.sum(zero_mask).item()
                mse[i] = num_zeros / y.shape[0]
    elif loss == 'both':
        class_err = torch.zeros(save_steps)
        true_label = torch.argmax(y, dim=1)
        for i in tqdm(range(save_steps)):
            if indices == None:
                if save_KXX==False:
                    pred = KmV(K, X, X, a[i])
                else:
                    pred = K @ a[i]
                if y.shape[1] == 1:
                    pred_label = (pred >= 0.5).int()
                    num_wrong = torch.sum(abs(pred_label - y))
                    class_err[i] = 1 - (num_wrong / y.shape[0])
                else:
                    max_indices = torch.argmax(pred, dim=1)
                    zero_mask = (abs(max_indices - true_label) == 0)
                    num_zeros = torch.sum(zero_mask).item()
                    class_err[i] = num_zeros / y.shape[0]
                mse[i] = (pred - y).pow(2).mean()
            else:
                alpha = torch.zeros_like(y, device=y.device)
                alpha[indices, :] = a[i]
                if save_KXX==False:
                    pred = KmV(K, X, X, alpha)
                else:
                    pred = K @ alpha
                if y.shape[1] == 1:
                    pred_label = (pred >= 0.5).int()
                    num_wrong = torch.sum(abs(pred_label - y))
                    class_err[i] = 1 - (num_wrong / y.shape[0])
                else:
                    max_indices = torch.argmax(pred, dim=1)
                    zero_mask = (abs(max_indices - true_label) == 0)
                    num_zeros = torch.sum(zero_mask).item()
                    class_err[i] = num_zeros / y.shape[0]
                mse[i] = (pred - y).pow(2).mean()
        return mse, class_err
    return mse

'''
DEV = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

DATADIR = 'SUSY.csv'
dataloader = Load_Data(DATADIR)
X, y = dataloader.loader(DATADIR)
n = X.shape[0]
X = X.to(DEV)
y = y.to(DEV)
X = X.double()
y = y.double()
X = 0.1 * X
print(DEV)

n = 1000
y = 100*torch.rand(n,5,device=DEV)
d = 50
X = 2*torch.rand(n, d, device=DEV) / math.sqrt(d)


beta, indices, mse = FALKON(X, y, None, 1000, K, 0, 100)




print('generating MSE')

mse = generate_mse(mse, K, X, y, indices=indices)
print(mse)
'''
