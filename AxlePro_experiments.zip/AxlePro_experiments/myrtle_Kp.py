import math
import numpy as np
import os
import random
import re
import pickle
from tqdm.auto import tqdm
import scipy
import torch
from plot import plot_graphs, save_data
from pytictoc import TicToc
# from torchkernels.kernels.radial import laplacian as KK
from torchkernels.kernels.radial import gaussian as K
from torchkernels.linalg.eigh import nystrom_extension


def nystrom_extension(K, X, Xs, E):
    """
        Extend eigenvectors
    """
    #E_ = K(X, Xs) @ E
    E_ = torch.zeros(X.shape[0], E.shape[1], device=X.device)
    iter_num = int(X.shape[0]/20000)
    for i in range(iter_num):
        E_[i*20000: (i+1)*20000, :] = K[i*20000: (i+1)*20000, Xs] @ E
    if iter_num * 20000 < X.shape[0]:
        E_[iter_num*20000:, :] = K[iter_num*20000:, Xs] @ E
    return E_/E_.norm(dim=0, keepdim=True)

def KmV(K, X, Z, v, out=None, row_chunk_size=20000, col_chunk_size=20000):
    """
        calculate kernel matrix vector product K(X, Z) @ v without storing kernel matrix
        If argument `out` is provided, the result is added to `out`
    """
    n_r, n_c = len(X), len(Z)
    b_r = n_r if row_chunk_size is None else row_chunk_size
    b_c = n_c if col_chunk_size is None else col_chunk_size
    return_flag = False
    if out is None:
        return_flag = True
        out = torch.zeros(n_r, *v.shape[1:], device=X.device)
    for i in range(math.ceil(n_r / b_r)):
        for j in range(math.ceil(n_c / b_c)):
            out[i * b_r:(i + 1) * b_r, :] += K(X[i * b_r:(i + 1) * b_r], Z[j * b_c:(j + 1) * b_c]) @ v[
                                                                                                  j * b_c:(j + 1) * b_c, :]

    if return_flag: return out


def generate_mse(a, KXX, X):
    save_steps = len(a)
    mse = torch.zeros(save_steps)
    for i in range(save_steps):
        mse[i] = (KXX @ a[i] - y).pow(2).mean()
        #print('loss=', mse[i])
    return mse




def top_eigen(KXX, X, q, scale):
    KXX = scale * KXX  ###or use nystrom
    L, E = torch.lobpcg(KXX, q + 1)
    mu, eigvec = torch.lobpcg(KXX, 1, largest=False)
    beta = (KXX.diag()/scale - (E[:, :q].pow(2) * (L[:q] - L[q])/scale).sum(-1)).max()
    return E[:, :q], L[:q], L[q], beta, mu

def top_eigen_eigh(KXX, X, q, scale):
    n = X.shape[0]
    KXX = scale * KXX  ###or use nystrom
    L, E = scipy.linalg.eigh(KXX.cpu().numpy(), subset_by_index=[n-q-1,n-1])
    L, E = torch.from_numpy(L).to(KXX.device).flipud(), torch.from_numpy(E).to(KXX.device).fliplr()
    mu = scipy.linalg.eigh(KXX.cpu().numpy(), eigvals_only=True, eigvals=(0, 0))
    mu = torch.from_numpy(mu).to(KXX.device).flipud()
    beta = (KXX.diag()/scale - (E[:, :q].pow(2) * (L[:q] - L[q])/scale).sum(-1)).max()
    return E[:, :q], L[:q], L[q], beta, mu




def hyperparam_selection(m, n, L1, lqp1, lam_min):
    L = lqp1 / n
    mu = lam_min / n
    L_1 = L1
    kappa_tilde = n
    kappa_tilde_m = kappa_tilde / m + (m - 1) / m
    L_m = L_1 / m + (m - 1) * L / m
    kappa_m = L_m / mu
    eta_1 = 1 / L_m
    eta_2 = ((eta_1 * torch.sqrt(kappa_m * kappa_tilde_m)) / (torch.sqrt(kappa_m * kappa_tilde_m) + 1)) * (
            1 - 1 / kappa_tilde_m)
    gamma = (torch.sqrt(kappa_m * kappa_tilde_m) - 1) / (torch.sqrt(kappa_m * kappa_tilde_m) + 1)
    return eta_1, eta_2, gamma


def richardson_iteration(step_size, KXX, alpha, y, m):
    N = KXX.shape[0]
    myList = list(range(0, N))
    batch_ind = sorted(random.sample(myList, k=m))
    alpha[batch_ind, :] = alpha[batch_ind, :] - step_size * (
            torch.matmul(KXX[batch_ind, :], alpha) - y[batch_ind, :])
    return alpha


def precondition_kernel_matrix(q, KXX, nystrom=0):
    if nystrom:
        L, E = torch.lobpcg(KXX, q + 1)
        return L, E
    else:
        L, E = torch.lobpcg(KXX, q + 1)
        F = E[:, :q] * (L[:q] - L[-1]).sqrt()
        return KXX - F @ F.T, L, E, F


def MaSS_SGD(alpha, beta, eta1, gamma, eta2, K, y, m, N):
    # m: batch size
    # N: number of data points
    myList = list(range(0, N))
    batch_ind = sorted(random.sample(myList, k=m))
    alpha_new = beta * 1
    gm = 1 / m * (torch.matmul(K[batch_ind, :], beta) - y[batch_ind, :])
    alpha_new[batch_ind, :] = alpha_new[batch_ind, :] - eta1 * gm
    beta_new = alpha_new + gamma * (alpha_new - alpha)
    beta_new[batch_ind, :] = beta_new[batch_ind, :] + eta2 * gm
    return alpha_new, beta_new


def hyperparam_selection_Kp(L, mu, L_1, m, n):
    kappa_tilde = n
    kappa_tilde_m = kappa_tilde / m + (m - 1) / m
    L_m = L_1 / m + (m - 1) * L / m
    kappa_m = L_m / mu
    eta_1 = 1 / L_m
    eta_2 = ((eta_1 * torch.sqrt(kappa_m * kappa_tilde_m)) / (torch.sqrt(kappa_m * kappa_tilde_m) + 1)) * (
                1 - 1 / kappa_tilde_m)
    gamma = (torch.sqrt(kappa_m * kappa_tilde_m) - 1) / (torch.sqrt(kappa_m * kappa_tilde_m) + 1)
    return eta_1, eta_2, gamma, 1 - 1 / torch.sqrt(kappa_m * kappa_tilde_m), 1 - 1 / kappa_m


'''
def best_step_size(KXX, m):
    N = KXX.shape[0]
    eigvals = torch.linalg.eigvalsh(KXX/N)
    beta = KXX.diag().max()
    return 2/(beta + (m - 1) * eigvals[-1])
'''

def top_eigensystem(KXX, X, q, method='scipy.linalg.eigh'):
    assert method in {"scipy.linalg.eigh", "torch.lobpcg"}
    """
      Top-q eigen system of K(X, X)/n
      where n = len(X)

      Args: 
        K: kernel that takes 2 arguments.
        X: of shape (n, d).
        q: number of eigen-modes

      Returns:
        E: top-q eigenvectors
        L: top-q eigenvalues of
        lqp1: q+1 st eigenvalue
        beta: max{i} of K(xi, xi) - \sum_j=1^q (L[i]-lqp1) psi_j(xi)**2
    """
  
    n = X.shape[0]
    scaled_kmat = KXX/n
    if method == "scipy.linalg.eigh":
      L, E = scipy.linalg.eigh(scaled_kmat.cpu().numpy(), subset_by_index=[n-q-1,n-1])
      L, E = torch.from_numpy(L).to(scaled_kmat.device).flipud(), torch.from_numpy(E).to(scaled_kmat.device).fliplr()
    elif method == "torch.lobpcg":
      L, E = torch.lobpcg(scaled_kmat, q+1)
    beta = n * (scaled_kmat.diag() - (E[:,:q].pow(2)*(L[:q]-L[q])).sum(-1)).max()
  
    return E[:,:q], L[:q], L[q], beta


def eigenpro(K, X, y, q, T, alpha_true=None, m=None, error=False, save_KXX=False, save_steps=100, nystrom=0, kernel=None):
    gap = T / save_steps
    n = X.shape[0]
    print('n=', n)
    nids = torch.randperm(n)[:nystrom]
    scale = n / nystrom
    print('start')
    print(X[nids].shape)
    print('K shape = ', K.shape)
    E, L, lqp1, beta= top_eigensystem(K[nids][:, nids], X[nids], q)
    print(beta)
    L, lqp1 = scale*L, scale*lqp1
    E = nystrom_extension(K, X, nids, E)
    E, R = torch.linalg.qr(E)
    F = E * (1 - lqp1 / L).sqrt()
    #beta = 1 
    a = torch.zeros_like(y, dtype=X.dtype, device=X.device)
    bs_crit = int(beta / lqp1)
    
    if m is None: m = bs_crit
    lr = lambda bs: 1 / beta if bs < bs_crit else 2 / (beta + (bs - 1) * lqp1)
    # print('eigenpro beta, lqp1, step size = ', beta, lqp1, lr(m))
    mse = [0]*(save_steps + 1) #torch.zeros(save_steps + 1)
    mse[0] = a*1#(KmV(K, X, X, a) - y).pow(2).mean()
    save_count = 0

    print(f"bs_crit={bs_crit}, m={m}, beta={beta}, l1={L[0] * n}, lqp1={lqp1 * n}, lr={lr(m)}")
    param_error = torch.zeros(T + 1)
    # param_error[0] = ((alpha_true - a).T) @ KXX @ (alpha_true - a)
    for t in tqdm(range(T)):
        myList = list(range(0, n))
        bids = sorted(random.sample(myList, k=m))
        g = K[bids, :] @ a - y[bids, :]
        g=g*0.7
        a[bids, :] = a[bids, :] - lr(len(bids)) * g
        a += lr(len(bids)) * (F @ (F[bids].T @ g))
        if error and (t + 1) % gap == 0:
            save_count += 1
            mse[save_count] = a*1#(KmV(K, X, X, a) - y).pow(2).mean()
            #print('eigenpro save_count=', save_count)
            # param_error[t+1] = ((alpha_true - a).T) @ KXX @ (alpha_true - a)
    return a if not error else (a, mse, param_error)



def PKmass_test(K, X, y, T, m, q, alpha_true=None, alpha=None, save_KXX=False, save_steps=100, nystrom=0):
    gap = T / save_steps
    n = X.shape[0]
    nids = torch.randperm(n)[:nystrom]
    scale = n/nystrom
    #E, L, lqp1, beta, mu = top_eigen(K, X[nids], q, scale)
    E, L, lqp1, beta, mu = top_eigen_eigh(K[nids][:, nids], X[nids], q, scale)
    print(mu)

    mu = mu * 3 #tune mu
    E = nystrom_extension(K, X, nids, E)
    E, R = torch.linalg.qr(E)
    F = E * (1 - lqp1 / L).sqrt()
    print(beta)
    bs_crit = int(beta / lqp1) + 1
    if m is None: m = bs_crit
    eta1, eta2, gamma = hyperparam_selection(m, n, beta, lqp1, mu)
    eta1, eta2 = 0.7*eta1 / m, 0.7*eta2 / m
    print('PMASS eta1, eta2, gamma:', eta1, eta2, gamma)
    print('beta=', beta)
    #alpha_true =1
    if alpha is None:
        b, a = torch.zeros_like(y, dtype=X.dtype, device=X.device), torch.zeros_like(y, dtype=X.dtype, device=X.device)
    else:
        a = (E * 1 / L) @ (E.T @ y)
        b = a * 1
    mse = [0]*(save_steps + 1) #torch.zeros(save_steps + 1)
    mse[0] = a*1#(KmV(K, X, X, a) - y).pow(2).mean()
    save_count = 0
    Pmass_param_error = torch.zeros(T + 1, device=X.device)
    # Pmass_param_error[0] = ((alpha_true - a).T) @ KXX @ (alpha_true - a)

    for t in tqdm(range(T)):
        myList = list(range(0, n))
        bids = sorted(random.sample(myList, k=m))
        gm = K[bids, :] @ b - y[bids]
        h = F @ (F[bids].T @ gm)
        a_ = a.clone()
        a = b + eta1 * h
        a[bids, :] -= eta1 * gm
        b = a + gamma * (a - a_) - eta2 * h
        b[bids, :] += eta2 * gm
        if (t + 1) % gap == 0:
            save_count += 1
            mse[save_count] = a*1#(KmV(K, X, X, a) - y).pow(2).mean()
        # Pmass_param_error[t+1] = (((alpha_true - a).T) @ KXX @ (alpha_true - a))
    return a, mse, Pmass_param_error




def conjugate_gradient(K, X, y, epochs=None, save_KXX=False, save_steps=100):
    n = X.shape[0]
    if epochs is None: epochs = n
    gap = epochs / save_steps
    a = torch.zeros_like(y, dtype=X.dtype, device=X.device)
    r = y.type(X.type()).clone()
    p = r.clone()
    mse = [0]*(save_steps + 1) #torch.zeros(save_steps + 1)
    mse[0] = a*1#(KmV(K, X, X, a) - y).pow(2).mean()
    save_count = 0
    for t in tqdm(range(epochs)):
        Kp = K @ p#KmV(K, X, X, p)
        r_norm2 = r.pow(2).sum(0)
        alpha = r_norm2 / (p * Kp).sum(0)
        a += alpha * p
        r -= alpha * Kp
        beta = r.pow(2).sum(0) / r_norm2
        p = r + beta * p
        if (t + 1) % gap == 0:
            save_count += 1
            mse[save_count] = a*1 #(KmV(K, X, X, a) - y).pow(2).mean()
            #print('CG save_count num=', save_count)
    return a, mse


def unpickle(file):
    import pickle
    with open(file, 'rb') as fo:
        dict = pickle.load(fo, encoding='bytes')
    return dict


def read_cifar10(DATADIR='cifar-10-batches-py', parts=5, train=False, validation=False):
    X = []
    y = []
    if train:
        for i in range(1, min(5, parts + 1)):
            data_dict = unpickle(
                os.path.join(DATADIR, f'data_batch_{i + 1}'))
            X.append(data_dict[b'data'])
            y.append(np.array(data_dict[b'labels']))
    if validation:
        data_dict = unpickle(
            os.path.join(DATADIR, f'data_batch_1'))
        X.append(data_dict[b'data'])
        y.append(np.array(data_dict[b'labels']))
    else:
        data_dict = unpickle(
            os.path.join(DATADIR, f'test_batch'))
        X.append(data_dict[b'data'])
        y.append(np.array(data_dict[b'labels']))
    X = torch.from_numpy(np.concatenate(X) / 255.).float()
    y = torch.from_numpy(np.concatenate(y))
    y = torch.nn.functional.one_hot(y.long()).to(torch.float32)
    np.random.seed(7)
    perm = np.arange(len(X))
    np.random.shuffle(perm)
    X, y = X[perm], y[perm]
    return X, y
