import numpy as np

NTK = np.load('NTK1.npy')
print(NTK.shape)
NTK_new = np.load('NTK3.npy')

NTK = np.concatenate((NTK, NTK_new), axis=0)

print(NTK.shape)

np.save('NTK1', NTK)

print('finish')