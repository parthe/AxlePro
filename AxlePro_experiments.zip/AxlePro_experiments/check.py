import numpy as np


file_path = 'NTK.npy'
KXX = np.load(file_path)
print(KXX.shape)

# r=1
# c=3
# K31 = KXX[(c-1)*20000:c*20000, (r-1)*20000:r*20000]
# #print('K13=', KXX[r*20000: r*20000 + 5, c*20000: c*20000 + 5])
# KXX[(r-1)*20000:r*20000, (c-1)*20000:c*20000] = K31.T

r=3
c=2
K23 = KXX[(c-1)*20000:c*20000, (r-1)*20000:r*20000]
#print('K13=', KXX[r*20000: r*20000 + 5, c*20000: c*20000 + 5])
KXX[(r-1)*20000:r*20000, (c-1)*20000:c*20000] = K23.T

np.save(file_path, KXX)
print('saved')