import math
import numpy as np
import os
import random
import re
import pickle
from tqdm.auto import tqdm
import scipy
import torch
from plot import plot_graphs, save_data
from pytictoc import TicToc;
# from torchkernels.kernels.radial import laplacian as KK
from torchkernels.kernels.radial import gaussian as K
from torchkernels.linalg.eigh import top_eigensystem, nystrom_extension

'''timer = TicToc()
torch.set_default_dtype(torch.float64)
print('------------------------program starts nystrom----------------------')
DEV = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
DATADIR = 'cifar-10-batches-py'
'''

def extract_time(input_string):
    # Define the regular expression pattern to find the time after 'CUDA time total:'
    pattern = r'CPU time total:\s*([\d.]+)*(s|ms|seconds|milliseconds)'

    # Search for the pattern in the input string
    match = re.search(pattern, input_string)

    # Check if a match was found
    if match:
        # Extract the matched time and unit
        time_str, unit = match.groups()

        # Convert the time to milliseconds as a float
        time_ms = float(time_str)

        # If the unit is 's' or 'seconds', convert to milliseconds
        if unit.lower() in ('s', 'seconds'):
            time_ms *= 1000

        return time_ms
    else:
        # If no match was found, return None
        return None

def nystrom_extension(K, X, Xs, E):
    """
        Extend eigenvectors
    """
    #E_ = K(X, Xs) @ E
    E_ = torch.zeros(X.shape[0], E.shape[1], device=X.device)
    iter_num = int(X.shape[0]/20000)
    for i in range(iter_num):
        E_[i*20000: (i+1)*20000, :] = K(X[i*20000: (i+1)*20000, :], Xs) @ E
    if iter_num * 20000 < X.shape[0]:
        E_[iter_num*20000:, :] = K(X[iter_num*20000:, :], Xs) @ E
    return E_/E_.norm(dim=0, keepdim=True)

def KmV(K, X, Z, v, out=None, row_chunk_size=20000, col_chunk_size=20000):
    """
        calculate kernel matrix vector product K(X, Z) @ v without storing kernel matrix
        If argument `out` is provided, the result is added to `out`
    """
    n_r, n_c = len(X), len(Z)
    b_r = n_r if row_chunk_size is None else row_chunk_size
    b_c = n_c if col_chunk_size is None else col_chunk_size
    return_flag = False
    if out is None:
        return_flag = True
        out = torch.zeros(n_r, *v.shape[1:], device=X.device)
    for i in range(math.ceil(n_r / b_r)):
        for j in range(math.ceil(n_c / b_c)):
            out[i * b_r:(i + 1) * b_r, :] += K(X[i * b_r:(i + 1) * b_r], Z[j * b_c:(j + 1) * b_c]) @ v[
                                                                                                  j * b_c:(j + 1) * b_c, :]

    if return_flag: return out


def generate_mse(a, K, X):
    save_steps = len(a)
    mse = torch.zeros(save_steps)
    for i in range(save_steps):
        mse[i] = (KmV(K, X, X, a[i]) - y).pow(2).mean()
        #print('loss=', mse[i])
    return mse




def top_eigen(K, X, q, scale):
    KXX = scale * K(X, X)  ###or use nystrom
    L, E = torch.lobpcg(KXX, q + 1)
    mu, eigvec = torch.lobpcg(KXX, 1, largest=False)
    beta = (KXX.diag()/scale - (E[:, :q].pow(2) * (L[:q] - L[q])/scale).sum(-1)).max()
    return E[:, :q], L[:q], L[q], beta, mu

def top_eigen_eigh(K, X, q, scale):
    n = X.shape[0]
    KXX = scale * K(X, X)  ###or use nystrom
    L, E = scipy.linalg.eigh(KXX.cpu().numpy(), subset_by_index=[n-q-1,n-1])
    L, E = torch.from_numpy(L).to(KXX.device).flipud(), torch.from_numpy(E).to(KXX.device).fliplr()
    mu = scipy.linalg.eigh(KXX.cpu().numpy(), eigvals_only=True, eigvals=(0, 0))
    mu = torch.from_numpy(mu).to(KXX.device).flipud()
    beta = (KXX.diag()/scale - (E[:, :q].pow(2) * (L[:q] - L[q])/scale).sum(-1)).max()
    return E[:, :q], L[:q], L[q], beta, mu




def hyperparam_selection(m, n, L1, lqp1, lam_min):
    L = lqp1 / n
    mu = lam_min / n
    L_1 = L1
    kappa_tilde = n
    kappa_tilde_m = kappa_tilde / m + (m - 1) / m
    L_m = L_1 / m + (m - 1) * L / m
    kappa_m = L_m / mu
    eta_1 = 1 / L_m
    eta_2 = ((eta_1 * torch.sqrt(kappa_m * kappa_tilde_m)) / (torch.sqrt(kappa_m * kappa_tilde_m) + 1)) * (
            1 - 1 / kappa_tilde_m)
    gamma = (torch.sqrt(kappa_m * kappa_tilde_m) - 1) / (torch.sqrt(kappa_m * kappa_tilde_m) + 1)
    return eta_1, eta_2, gamma


def richardson_iteration(step_size, KXX, alpha, y, m):
    N = KXX.shape[0]
    myList = list(range(0, N))
    batch_ind = sorted(random.sample(myList, k=m))
    alpha[batch_ind, :] = alpha[batch_ind, :] - step_size * (
            torch.matmul(KXX[batch_ind, :], alpha) - y[batch_ind, :])
    return alpha


def precondition_kernel_matrix(q, KXX, nystrom=0):
    if nystrom:
        L, E = torch.lobpcg(KXX, q + 1)
        return L, E
    else:
        L, E = torch.lobpcg(KXX, q + 1)
        F = E[:, :q] * (L[:q] - L[-1]).sqrt()
        return KXX - F @ F.T, L, E, F


def MaSS_SGD(alpha, beta, eta1, gamma, eta2, K, y, m, N):
    # m: batch size
    # N: number of data points
    myList = list(range(0, N))
    batch_ind = sorted(random.sample(myList, k=m))
    alpha_new = beta * 1
    gm = 1 / m * (torch.matmul(K[batch_ind, :], beta) - y[batch_ind, :])
    alpha_new[batch_ind, :] = alpha_new[batch_ind, :] - eta1 * gm
    beta_new = alpha_new + gamma * (alpha_new - alpha)
    beta_new[batch_ind, :] = beta_new[batch_ind, :] + eta2 * gm
    return alpha_new, beta_new


def hyperparam_selection_Kp(L, mu, L_1, m, n):
    kappa_tilde = n
    kappa_tilde_m = kappa_tilde / m + (m - 1) / m
    L_m = L_1 / m + (m - 1) * L / m
    kappa_m = L_m / mu
    eta_1 = 1 / L_m
    eta_2 = ((eta_1 * torch.sqrt(kappa_m * kappa_tilde_m)) / (torch.sqrt(kappa_m * kappa_tilde_m) + 1)) * (
                1 - 1 / kappa_tilde_m)
    gamma = (torch.sqrt(kappa_m * kappa_tilde_m) - 1) / (torch.sqrt(kappa_m * kappa_tilde_m) + 1)
    return eta_1, eta_2, gamma, 1 - 1 / torch.sqrt(kappa_m * kappa_tilde_m), 1 - 1 / kappa_m


'''
def best_step_size(KXX, m):
    N = KXX.shape[0]
    eigvals = torch.linalg.eigvalsh(KXX/N)
    beta = KXX.diag().max()
    return 2/(beta + (m - 1) * eigvals[-1])
'''


def eigenpro(K, X, y, q, T, alpha_true=None, m=None, error=False, save_KXX=False, save_steps=100, nystrom=0):
    gap = T / save_steps
    n = X.shape[0]
    
    nids = torch.randperm(n)[:nystrom]
    scale = 1#n / nystrom
    print('start')
    print(X[nids].shape)
    E, L, lqp1, beta= top_eigensystem(K, X[nids], q)
    print(beta)
    L, lqp1 = scale*L, scale*lqp1
    E = nystrom_extension(K, X, X[nids], E)
    E, R = torch.linalg.qr(E)
    F = E * (1 - lqp1 / L).sqrt()
    #beta = 1 
    a = torch.zeros_like(y, dtype=X.dtype, device=X.device)
    bs_crit = int(beta / lqp1)
    
    if m is None: m = bs_crit
    lr = lambda bs: 1 / beta if bs < bs_crit else 2 / (beta + (bs - 1) * lqp1)
    # print('eigenpro beta, lqp1, step size = ', beta, lqp1, lr(m))
    mse = [0]*(save_steps + 1) #torch.zeros(save_steps + 1)
    mse[0] = a*1#(KmV(K, X, X, a) - y).pow(2).mean()
    save_count = 0

    print(f"bs_crit={bs_crit}, m={m}, beta={beta}, l1={L[0] * n}, lqp1={lqp1 * n}, lr={lr(m)}")
    param_error = torch.zeros(T + 1)
    # param_error[0] = ((alpha_true - a).T) @ KXX @ (alpha_true - a)
    for t in tqdm(range(T)):
        myList = list(range(0, n))
        bids = sorted(random.sample(myList, k=m))
        g = K(X[bids], X) @ a - y[bids, :]
        #g=g*0.5
        a[bids, :] = a[bids, :] - lr(len(bids)) * g
        a += lr(len(bids)) * (F @ (F[bids].T @ g))
        if error and (t + 1) % gap == 0:
            save_count += 1
            mse[save_count] = a*1#(KmV(K, X, X, a) - y).pow(2).mean()
            #print('eigenpro save_count=', save_count)
            # param_error[t+1] = ((alpha_true - a).T) @ KXX @ (alpha_true - a)
    return a if not error else (a, mse, param_error)



def PKmass_test(K, X, y, T, m, q, alpha_true=None, alpha=None, save_KXX=False, save_steps=100, nystrom=0):
    gap = T / save_steps
    n = X.shape[0]

    nids = torch.randperm(n)[:nystrom]
    scale =1# n/nystrom
    #E, L, lqp1, beta, mu = top_eigen(K, X[nids], q, scale)
    E, L, lqp1, beta, mu = top_eigen_eigh(K, X[nids], q, scale)
    print(mu)
    #mu=0.0003
    #mu = mu * 0.1 #tune mu
    E = nystrom_extension(K, X, X[nids], E)
    E, R = torch.linalg.qr(E)
    F = E * (1 - lqp1 / L).sqrt()
    print(beta)
    bs_crit = int(beta / lqp1) + 1
    if m is None: m = bs_crit
    eta1, eta2, gamma = hyperparam_selection(m, n, beta, lqp1, mu)
    eta1, eta2 = eta1 / m, eta2 / m
    print('PMASS eta1, eta2, gamma:', eta1, eta2, gamma)
    print('beta=', beta)
    #alpha_true =1
    if alpha is None:
        b, a = torch.zeros_like(y, dtype=X.dtype, device=X.device), torch.zeros_like(y, dtype=X.dtype, device=X.device)
    else:
        a = (E * 1 / L) @ (E.T @ y)
        b = a * 1
    mse = [0]*(save_steps + 1) #torch.zeros(save_steps + 1)
    mse[0] = a*1#(KmV(K, X, X, a) - y).pow(2).mean()
    save_count = 0
    Pmass_param_error = torch.zeros(T + 1, device=X.device)
    # Pmass_param_error[0] = ((alpha_true - a).T) @ KXX @ (alpha_true - a)

    for t in tqdm(range(T)):
        myList = list(range(0, n))
        bids = sorted(random.sample(myList, k=m))
        gm = K(X[bids], X) @ b - y[bids]
        h = F @ (F[bids].T @ gm)
        a_ = a.clone()
        a = b + eta1 * h
        a[bids, :] -= eta1 * gm
        b = a + gamma * (a - a_) - eta2 * h
        b[bids, :] += eta2 * gm
        if (t + 1) % gap == 0:
            save_count += 1
            mse[save_count] = a*1#(KmV(K, X, X, a) - y).pow(2).mean()
        # Pmass_param_error[t+1] = (((alpha_true - a).T) @ KXX @ (alpha_true - a))
    return a, mse, Pmass_param_error




def conjugate_gradient(K, X, y, epochs=None, save_KXX=False, save_steps=100):
    n = X.shape[0]
    if epochs is None: epochs = n
    gap = epochs / save_steps
    a = torch.zeros_like(y, dtype=X.dtype, device=X.device)
    r = y.type(X.type()).clone()
    p = r.clone()
    mse = [0]*(save_steps + 1) #torch.zeros(save_steps + 1)
    mse[0] = a*1#(KmV(K, X, X, a) - y).pow(2).mean()
    save_count = 0
    for t in tqdm(range(epochs)):
        Kp = KmV(K, X, X, p)
        r_norm2 = r.pow(2).sum(0)
        alpha = r_norm2 / (p * Kp).sum(0)
        a += alpha * p
        r -= alpha * Kp
        beta = r.pow(2).sum(0) / r_norm2
        p = r + beta * p
        if (t + 1) % gap == 0:
            save_count += 1
            mse[save_count] = a*1 #(KmV(K, X, X, a) - y).pow(2).mean()
            #print('CG save_count num=', save_count)
    return a, mse


def unpickle(file):
    import pickle
    with open(file, 'rb') as fo:
        dict = pickle.load(fo, encoding='bytes')
    return dict


def read_cifar10(DATADIR='cifar-10-batches-py', parts=5, train=False, validation=False):
    X = []
    y = []
    if train:
        for i in range(1, min(5, parts + 1)):
            data_dict = unpickle(
                os.path.join(DATADIR, f'data_batch_{i + 1}'))
            X.append(data_dict[b'data'])
            y.append(np.array(data_dict[b'labels']))
    if validation:
        data_dict = unpickle(
            os.path.join(DATADIR, f'data_batch_1'))
        X.append(data_dict[b'data'])
        y.append(np.array(data_dict[b'labels']))
    else:
        data_dict = unpickle(
            os.path.join(DATADIR, f'test_batch'))
        X.append(data_dict[b'data'])
        y.append(np.array(data_dict[b'labels']))
    X = torch.from_numpy(np.concatenate(X) / 255.).float()
    y = torch.from_numpy(np.concatenate(y))
    y = torch.nn.functional.one_hot(y.long()).to(torch.float32)
    np.random.seed(7)
    perm = np.arange(len(X))
    np.random.shuffle(perm)
    X, y = X[perm], y[perm]
    return X, y



def eigenpro2(K, X, y, q, T, alpha_true=None, m=None, error=False, save_KXX=False, save_steps=100, nystrom=0):
    gap = T / save_steps
    n = X.shape[0]
    
    nids = torch.randperm(n)[:nystrom]
    scale = n / nystrom
    print('start')
    print(X[nids].shape)
    E, L, lqp1, beta= top_eigensystem(K, X[nids], q)
    print(beta)
    L, lqp1 = scale*L, scale*lqp1
    E = nystrom_extension(K, X, X[nids], E)
    E, R = torch.linalg.qr(E)
    F = E * (1 - lqp1 / L).sqrt()
    #beta = 1 
    a = torch.zeros_like(y, dtype=X.dtype, device=X.device)
    bs_crit = int(beta / lqp1)
    
    if m is None: m = bs_crit
    lr = lambda bs: 1 / beta if bs < bs_crit else 2 / (beta + (bs - 1) * lqp1)
    # print('eigenpro beta, lqp1, step size = ', beta, lqp1, lr(m))
    mse = [0]*(save_steps + 1) #torch.zeros(save_steps + 1)
    mse[0] = a*1#(KmV(K, X, X, a) - y).pow(2).mean()
    save_count = 0

    print(f"bs_crit={bs_crit}, m={m}, beta={beta}, l1={L[0] * n}, lqp1={lqp1 * n}, lr={lr(m)}")
    param_error = torch.zeros(T + 1)
    # param_error[0] = ((alpha_true - a).T) @ KXX @ (alpha_true - a)
    for t in tqdm(range(T)):
        myList = list(range(0, n))
        bids = sorted(random.sample(myList, k=m))
        g = K(X[bids], X) @ a - y[bids, :]
        #g=g*0.5
        a[bids, :] = a[bids, :] - lr(len(bids)) * g
        a += lr(len(bids)) * (F @ (F[bids].T @ g))
        if error and (t + 1) % gap == 0:
            save_count += 1
            mse[save_count] = a*1#(KmV(K, X, X, a) - y).pow(2).mean()
            #print('eigenpro save_count=', save_count)
            # param_error[t+1] = ((alpha_true - a).T) @ KXX @ (alpha_true - a)
    return a if not error else (a, mse, param_error)

'''
torch.manual_seed(0)
X, y = read_cifar10(DATADIR, parts=5, train=True)


X = X.to(DEV)
y = y.to(DEV)
n = X.shape[0]
X = X.double()
y = y.double()
X = 0.1 * X

file_name = 'data_nystrom_full_cifar.pkl'
alg = 'eigenpro'
# synthetic data
n = 1000
d = 50
X = torch.rand(n, d, device=DEV) / math.sqrt(d)
y = torch.rand(n, 10, device=X.device)  # - 0.3

print(y.device)
# y = y.sign()
# KXX = K(X, X)
q = 100
m = 100
T = 4000
save_steps = 100  # so output MSE will have save_steps+1 data points
nystrom = 1000
gap = T / save_steps
epochs = 2000
gap_cg = epochs / save_steps
t_cg = gap_cg * np.arange(save_steps + 1)
t = gap * np.arange(save_steps + 1)
save_KXX = False
alpha_true = torch.zeros(n, 1, device=X.device)  # torch.linalg.solve(K, y)




if alg=='cg':
    with torch.profiler.profile(
            activities=[
                torch.profiler.ProfilerActivity.CPU,
                torch.profiler.ProfilerActivity.CUDA,
            ],
            use_cuda=True
    ) as p:
        CG_MSE = conjugate_gradient(K, X, y, epochs=epochs, save_KXX=save_KXX, save_steps=save_steps)
    table = p.key_averages().table(
        sort_by="self_cuda_time_total", row_limit=-1)
    cg_time = extract_time(table)
    print('cg_time', cg_time)
    epochs = X.shape[0] if epochs == None else epochs
    print('generating CG_MSE')
    CG_MSE = generate_mse(CG_MSE, K, X)
elif alg=='eigenpro':
    with torch.profiler.profile(
            activities=[
                torch.profiler.ProfilerActivity.CPU,
                torch.profiler.ProfilerActivity.CUDA,
            ],
            use_cuda=True
    ) as p:
        a, MSE_Eigenpro, Eigenpro_param_error = eigenpro(K, X, y, q, T, m=m, error=True, save_KXX=save_KXX,
                                                         save_steps=save_steps, nystrom=nystrom)
    table = p.key_averages().table(
        sort_by="self_cuda_time_total", row_limit=-1)
    eigenpro_time = extract_time(table)
    print('eigenpro_time', eigenpro_time)
    print('generating MSE_Eigenpro')
    MSE_Eigenpro = generate_mse(MSE_Eigenpro, K, X)
elif alg=='pmass':
    # setup time
    setup_time = [0, 0]
    #KXX = K(X, X)
    nids = torch.randperm(n)[:nystrom]
    KXX_nystrom = K(X[nids], X[nids])
    with torch.profiler.profile(
            activities=[
                torch.profiler.ProfilerActivity.CPU,
                torch.profiler.ProfilerActivity.CUDA,
            ],
            use_cuda=True
    ) as p:
        L, E = torch.lobpcg(KXX_nystrom, q + 1)
    table = p.key_averages().table(
        sort_by="self_cuda_time_total", row_limit=-1)
    setup_time[0] = extract_time(table)
    print('setup_time(largest eigen)', setup_time[0])

    with torch.profiler.profile(
            activities=[
                torch.profiler.ProfilerActivity.CPU,
                torch.profiler.ProfilerActivity.CUDA,
            ],
            use_cuda=True
    ) as p:
        # Shifted_KXX = (L[0]+1000) * torch.eye(n) - KXX
        mu, eigvec = torch.lobpcg(KXX_nystrom, 1, largest=False)
        # mu = L[0]+1000-mu
    table = p.key_averages().table(
        sort_by="self_cuda_time_total", row_limit=-1)
    setup_time[1] = extract_time(table)
    print('setup_time(smallest eigen)', setup_time[1])


    with torch.profiler.profile(
            activities=[
                torch.profiler.ProfilerActivity.CPU,
                torch.profiler.ProfilerActivity.CUDA,
            ],
            use_cuda=True
    ) as p:
        MSE_Pmass, Pmass_param_error = PKmass_test(K, X, y, T, m, q, alpha_true, save_KXX=save_KXX, save_steps=save_steps, nystrom=nystrom)
    table = p.key_averages().table(
        sort_by="self_cuda_time_total", row_limit=-1)
    Pmass_time = extract_time(table)
    print('Pmass_time', Pmass_time)
    print('generating MSE_Pmass')
    MSE_Pmass = generate_mse(MSE_Pmass, K, X)





'''

'''
def generate_dict(alg):
    if alg=='cg':
        dict = {'save_KXX': save_KXX, 't_cg': t_cg, 'CG_MSE': CG_MSE,'cg_time': cg_time}
    elif alg=='eigenpro':
        dict = {'save_KXX': save_KXX, 't': t,
                'MSE_Eigenpro': MSE_Eigenpro, 'eigenpro_time': eigenpro_time}
    else:
        dict = {'save_KXX': save_KXX, 't': t, 'MSE_Pmass': MSE_Pmass, 'setup_time': setup_time,
                 'Pmass_time': Pmass_time,
                }
    return dict

dict = generate_dict(alg)
'''
# dict = {'save_KXX': save_KXX, 't_cg': t_cg, 't': t, 'CG_MSE': CG_MSE, 'MSE_Pmass': MSE_Pmass,
#          'MSE_Eigenpro': MSE_Eigenpro, 'setup_time': setup_time,
#         'cg_time': cg_time, 'Pmass_time': Pmass_time,
#         'eigenpro_time': eigenpro_time}

'''
print('saving data')
save_data(file_name, dict)

print('finish')
plot_graphs(file_name, nystrom=nystrom)
#plot_graphs(file_name, nystrom=nystrom)
############### evaluating mse

'''