import pickle
import torch
import matplotlib.pyplot as plt
import numpy as np
import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"

with open('../cifar_gaussian_test', 'rb') as file:
    data = pickle.load(file)
print(1)
# data['falkon']['MSE'][11:] = torch.tensor([0.0044]).repeat(1,10)
# data['falkon']['class_err'][11:] = torch.tensor([0.9917]).repeat(1,10)

save_steps = 20+1
color_dict = {'EigenPro': '-b^', 'AxlePro': '-gs', 'CG': '-yd', 'PCG': '-ro', 'Falkon': '-c*', 'GPyTorch': '-m1'}
shape_dict = {'EigenPro': 'blue', 'AxlePro': 'green', 'CG': 'yellow', 'PCG': 'red', 'Falkon': 'purple', 'GPyTorch': 'peru'}

min_time = min(data['falkon']['time'], data['cg']['time'], data['pcg']['time'] - data['pcg']['setup_time'],
               data['pmass']['time'] - data['pmass']['setup_time'][0] - data['pmass']['setup_time'][1],
               data['eigenpro']['time'] - data['pmass']['setup_time'][0])#, data['gpytorch']['time']
falkon_time = np.linspace(0, data['falkon']['time'], num=save_steps)
data['falkon']['time'] = falkon_time

cg_time = np.linspace(0, data['cg']['time'], num=save_steps)
data['cg']['time'] = cg_time

pcg_time = np.linspace(0, data['pcg']['time'] - data['pcg']['setup_time'], num=save_steps)
data['pcg']['time'] = pcg_time

pmass_time = np.linspace(0, data['pmass']['time'] - data['pmass']['setup_time'][0] - data['pmass']['setup_time'][1], num=save_steps)
data['pmass']['time'] = pmass_time

eigenpro_time = np.linspace(0, data['eigenpro']['time'] - data['pmass']['setup_time'][0], num=save_steps)
data['eigenpro']['time'] = eigenpro_time

# gpytorch_time = np.linspace(0, data['gpytorch']['time'], num=save_steps)
# data['gpytorch']['time'] = gpytorch_time

data['EigenPro'] = data.pop('eigenpro')
data['AxlePro'] = data.pop('pmass')
data['CG'] =data.pop('cg') #
data['PCG'] =data.pop('pcg') #
data['Falkon'] = data.pop('falkon')

#data.pop('gpytorch')#data['GPyTorch'] =
n=50000
steps_per_epoch = n/2000
gp_per_epoch = n/1000
data['EigenPro']['steps'] = data['EigenPro']['steps']/steps_per_epoch
data['AxlePro']['steps'] = data['AxlePro']['steps']/steps_per_epoch
#data['GPyTorch']['steps'] = data['GPyTorch']['steps']/gp_per_epoch

#marks_on = [int(i * (save_steps-1)/5) for i in range(1, 5)]

min_epochs = min(data['Falkon']['steps'][-1],
               data['AxlePro']['steps'][-1], data['EigenPro']['steps'][-1])#, data['PCG']['steps'][-1], data['CG']['steps'][-1], data['GPyTorch']['steps'][-1])
for key, value in data.items():
    steps = value['steps']
    MSE = value['MSE']

    plt.plot(steps, MSE, color_dict[key], label=key)
plt.yscale('log')
plt.xlabel('Epochs')
plt.xlim(0, min_epochs)
plt.ylabel('MSE (train)')
plt.legend()
plt.show()
plt.clf()

for key, value in data.items():
    steps = value['steps']
    class_err = value['class_err']
    plt.plot(steps, class_err, label=key)

plt.xlabel('Epochs')
plt.ylabel('Classification Error on Training Set')
plt.legend()
plt.show()
plt.clf()
marks_on = [int(i * (save_steps-1)/5) for i in range(1, 5)]
for key, value in data.items():
    time = 1+value['time']
    MSE = value['MSE']
    # if key=='GPyTorch':
    #     continue
    plt.plot(time, MSE, color_dict[key], label=key, markevery=marks_on)
plt.yscale('log')
#plt.xscale('log')
plt.xlim(1, min_time)
plt.xlabel('Time (s)')
plt.ylabel('MSE (train)')
plt.legend()
plt.show()
plt.clf()

for key, value in data.items():
    time = value['time']
    class_err = value['class_err']
    plt.plot(time, class_err, label=key)


plt.xlim(0, min_time)
plt.xlabel('Time')
plt.ylabel('Classification Error on Training Set')
plt.legend()
plt.show()
plt.clf()

for key, value in data.items():
    time = value['time']
    class_err = value['test_class_err_all']
    plt.plot(time, class_err, label=key)


plt.xlim(0, min_time)
plt.xlabel('Time')
plt.ylabel('Classification Error on Testing Set')
plt.legend()
plt.show()
plt.clf()