import load_data_utils

class Load_Data():
    def __init__(self, DATADIR):
        match DATADIR:
            case 'cifar-10-batches-py':
                self.loader = load_data_utils.read_cifar10
            case 'SUSY.csv':
                self.loader = load_data_utils.read_susy
            case 'star_classification.csv':
                self.loader = load_data_utils.read_star
            case 'emnist-digits-train.csv':
                self.loader = load_data_utils.read_emnist
            case 'YearPrediction.txt':
                self.loader = load_data_utils.read_year_pred

