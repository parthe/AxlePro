import gpytorch
import torch
import math
from tqdm.auto import tqdm

from linear_operator.operators import KernelLinearOperator
from torchkernels.kernels.radial import gaussian as K
import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
torch.set_default_dtype(torch.float64)

def gaussian_ker(x1, x2):

    sq_dist = (x1.unsqueeze(-2) - x2.unsqueeze(-3)).square().sum(dim=-1)
    kern = sq_dist.div(-2.0).exp()
    return kern

def laplacian_ker(x1, x2):
    sq_dist = (x1.unsqueeze(-2) - x2.unsqueeze(-3)).square().sum(dim=-1).sqrt()
    kern = sq_dist.div(-1.0).exp()
    return kern

def covar_func(x1, x2, lengthscale, outputscale):
    # RBF kernel function
    # x1: ... x N x D
    # x2: ... x M x D
    # lengthscale: ... x 1 x D
    # outputscale: ...
    x1 = x1.div(lengthscale)
    x2 = x2.div(lengthscale)
    sq_dist = (x1.unsqueeze(-2) - x2.unsqueeze(-3)).square().sum(dim=-1)
    kern = sq_dist.div(-2.0).exp().mul(outputscale[..., None, None].square())
    return kern
def precond(L, sigma, y):

    return y/(sigma**2) - (L @ torch.linalg.solve(torch.eye(L.shape[1], device=y.device) + (L.t() @ L)/(sigma**2), (L.t() @ y)))/(sigma**4)


def PKmV(K, X, Z, v, L, sigma, out=None, row_chunk_size=10000, col_chunk_size=10000):
    """
        calculate kernel matrix vector product K(X, Z) @ v without storing kernel matrix
        If argument `out` is provided, the result is added to `out`
    """
    n_r, n_c = len(X), len(Z)
    b_r = n_r if row_chunk_size is None else row_chunk_size
    b_c = n_c if col_chunk_size is None else col_chunk_size
    return_flag = False
    if out is None:
        return_flag = True
        out = torch.zeros(n_r, *v.shape[1:], device=X.device)
    for i in range(math.ceil(n_r / b_r)):
        for j in range(math.ceil(n_c / b_c)):
            out[i * b_r:(i + 1) * b_r, :] += K(X[i * b_r:(i + 1) * b_r], Z[j * b_c:(j + 1) * b_c]) @ v[
                                                                                                  j * b_c:(j + 1) * b_c, :]
    out = precond(L, sigma, out)
    if return_flag: return out

def precond_conjugate_gradient(K, X, y, L, sigma, epochs=None, save_KXX=False, save_steps=100):
    n = X.shape[0]
    if epochs is None: epochs = n
    if save_KXX:
        KXX = K(X, X)
        #KXX = K
    gap = epochs / save_steps
    a = torch.zeros_like(y, dtype=X.dtype, device=X.device)
    y = precond(L, sigma, y)
    r = y.type(X.type()).clone()
    p = r.clone()
    mse = [0]*(save_steps + 1) #torch.zeros(save_steps + 1)
    mse[0] = a*1#(KmV(K, X, X, a) - y).pow(2).mean()
    save_count = 0
    for t in tqdm(range(epochs)):
        if save_KXX:
            Kp = precond(L, sigma, KXX @ p)#PKmV(K, X, X, p, L, sigma)
        else:
            Kp = PKmV(K, X, X, p, L, sigma)
        r_norm2 = r.pow(2).sum(0)
        alpha = r_norm2 / (p * Kp).sum(0)
        a += alpha * p
        r -= alpha * Kp
        beta = r.pow(2).sum(0) / r_norm2
        p = r + beta * p
        if (t + 1) % gap == 0:
            save_count += 1
            mse[save_count] = a*1 #(KmV(K, X, X, a) - y).pow(2).mean()
            #print('CG save_count num=', save_count)
    return a, mse


'''#K = gpytorch.kernels.RBFKernel()
X=torch.rand(100,10)
y=torch.rand(100,2)
ker_operator = KernelLinearOperator(
    X, X, #lengthscale=lengthscale, outputscale=outputscale,
    covar_func=gaussian_ker, num_nonbatch_dimensions={"outputscale": 0}
)

sigma = 1
k=50
#KXX=KKK(X,X)
L = gpytorch.pivoted_cholesky(ker_operator, k, error_tol=None, return_pivots=False)

mse = precond_conjugate_gradient(K, X, y, L, sigma, epochs=100, save_steps=100)
for alpha in mse:
    print(((gaussian_ker(X,X) @ alpha) - y).pow(2).mean())
'''