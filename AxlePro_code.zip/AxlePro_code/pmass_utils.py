import re
import torch
import math
from tqdm.auto import tqdm


def extract_time(input_string):
    # Define the regular expression pattern to find the time after 'CUDA time total:'
    pattern = r'CPU time total:\s*([\d.]+)*(s|ms|seconds|milliseconds)'

    # Search for the pattern in the input string
    match = re.search(pattern, input_string)

    # Check if a match was found
    if match:
        # Extract the matched time and unit
        time_str, unit = match.groups()

        # Convert the time to milliseconds as a float
        time_ms = float(time_str)

        # If the unit is 's' or 'seconds', convert to milliseconds
        if unit.lower() in ('s', 'seconds'):
            time_ms *= 1000

        return time_ms
    else:
        # If no match was found, return None
        return None


def generate_mse(a, K, X, y, indices=None):
    save_steps = len(a)
    mse = torch.zeros(save_steps)
    for i in tqdm(range(save_steps)):
        if indices == None:
            mse[i] = (KmV(K, X, X, a[i]) - y).pow(2).mean()
        else:
            alpha = torch.zeros_like(y, device=y.device)
            alpha[indices, :] = a[i]
            mse[i] = (KmV(K, X, X, alpha) - y).pow(2).mean()
        # print('loss=', mse[i])
    return mse


def KmV(K, X, Z, v, out=None, row_chunk_size=10000, col_chunk_size=10000):
    """
        calculate kernel matrix vector product K(X, Z) @ v without storing kernel matrix
        If argument `out` is provided, the result is added to `out`
    """
    n_r, n_c = len(X), len(Z)
    b_r = n_r if row_chunk_size is None else row_chunk_size
    b_c = n_c if col_chunk_size is None else col_chunk_size
    return_flag = False
    if out is None:
        return_flag = True
        out = torch.zeros(n_r, *v.shape[1:], device=X.device)
    for i in range(math.ceil(n_r / b_r)):
        for j in range(math.ceil(n_c / b_c)):
            out[i * b_r:(i + 1) * b_r, :] += K(X[i * b_r:(i + 1) * b_r], Z[j * b_c:(j + 1) * b_c]) @ v[
                                                                                            j * b_c:(j + 1) * b_c, :]

    if return_flag: return out