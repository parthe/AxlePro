import os
import numpy as np
import torch
import pandas as pd

def unpickle(file):
    import pickle
    with open(file, 'rb') as fo:
        dict = pickle.load(fo, encoding='bytes')
    return dict

def read_cifar10(DATADIR=None, parts=5, test=False, validation=False):
    X = []
    y = []
    if test==False:
        for i in range(1, min(6, parts + 1)):
            data_dict = unpickle(
                os.path.join(DATADIR, f'data_batch_{i}'))
            X.append(data_dict[b'data'])
            y.append(np.array(data_dict[b'labels']))
    if validation:
        data_dict = unpickle(
            os.path.join(DATADIR, f'data_batch_1'))
        X.append(data_dict[b'data'])
        y.append(np.array(data_dict[b'labels']))
    if test==True:
        data_dict = unpickle(
            os.path.join(DATADIR, f'test_batch'))
        X.append(data_dict[b'data'])
        y.append(np.array(data_dict[b'labels']))
    X = torch.from_numpy(np.concatenate(X) / 255.).float()
    y = torch.from_numpy(np.concatenate(y))
    y = torch.nn.functional.one_hot(y.long()).to(torch.float32)
    return X, y

def read_susy(DATADIR, train_ratio=None):
    susy = pd.read_csv(DATADIR)
    susy_tensor = torch.tensor(susy.to_numpy())
    if train_ratio==None:
        # num_classes = 2
        # one_hot_matrix = torch.eye(num_classes)
        # one_hot_encoded = one_hot_matrix[torch.squeeze(susy_tensor[:, 0:1].to(dtype=torch.int))]
        return susy_tensor[:1000000, 1:], susy_tensor[:1000000, 0].unsqueeze(dim=1)
    else:
        dataset_size = susy_tensor.shape[0]
        train_size = int(train_ratio * dataset_size)
    return susy_tensor[:train_size, 1:], susy_tensor[:train_size, 0:1], susy_tensor[train_size:, 1:], susy_tensor[train_size:, 0:1] #X_train, y_train, X_test, y_test


def read_star(DATADIR, test=False):
    if test==True:
        star = pd.read_csv(DATADIR)
        star_tensor = torch.tensor(star.to_numpy())
        one_hot_matrix = torch.eye(3)
        one_hot_encoded = one_hot_matrix[torch.squeeze(star_tensor[:, -1].to(dtype=torch.int))]
        return star_tensor[:5000, :-1], one_hot_encoded[:5000, :]
    else:
        star = pd.read_csv(DATADIR)
        star_tensor = torch.tensor(star.to_numpy())
        one_hot_matrix = torch.eye(3)
        one_hot_encoded = one_hot_matrix[torch.squeeze(star_tensor[:, -1].to(dtype=torch.int))]
        return star_tensor[5000:, :-1], one_hot_encoded[5000:, :]

def read_emnist(DATADIR, test=False):
    if test==True:
        emnist = pd.read_csv('emnist-digits-test.csv')
        emnist_tensor = torch.tensor(emnist.to_numpy())
        one_hot_matrix = torch.eye(10)
        one_hot_encoded = one_hot_matrix[torch.squeeze(emnist_tensor[:, 0].to(dtype=torch.int))]
        return emnist_tensor[:, 1:], one_hot_encoded
    else:
        emnist = pd.read_csv(DATADIR)
        emnist_tensor = torch.tensor(emnist.to_numpy())
        one_hot_matrix = torch.eye(10)
        one_hot_encoded = one_hot_matrix[torch.squeeze(emnist_tensor[:, 0].to(dtype=torch.int))]
        return emnist_tensor[:, 1:], one_hot_encoded


def read_year_pred(DATADIR, test=False):
    if test == False:
        X = pd.read_table('YearPrediction.txt', header=None, sep=',')
        X_tensor = torch.tensor(X.to_numpy())
        X_train = X_tensor[:463715, 1:]
        y_train = X_tensor[:463715, 0].unsqueeze(1)
        return X_train, y_train
    if test == True:
        X = pd.read_table('YearPrediction.txt', header=None, sep=',')
        X_tensor = torch.tensor(X.to_numpy())
        X_test = X_tensor[463715:, 1:]
        y_test = X_tensor[463715:, 0].unsqueeze(1)
        return X_test, y_test
