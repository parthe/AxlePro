import math
import time
import gpytorch
import numpy as np
import torch
from torchkernels.kernels.radial import gaussian as K
from linear_operator.operators import KernelLinearOperator
from linear_operator import to_linear_operator
import scipy

from myrtle_Kp import eigenpro, conjugate_gradient, PKmass_test
from gpytorch_test import gpytorch_test, gpytorch_mse
from pcg import gaussian_ker, laplacian_ker, precond_conjugate_gradient
from falkon_test import FALKON, generate_mse, generate_mse_test
from load_data import Load_Data
from save_data import Save_Data
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
torch.set_default_dtype(torch.float64)

def run_example(alg, X, y, X_test, y_test, K, T, bs=2048, q=500, nystrom=20000, num_inducing_points=20000):
    setup_time = None
    mse = None
    class_err = None
    alg_time = None
    test_mse_all=None
    test_class_err_all=None
    save_steps = 20
    save_KXX=True
    gap = T / save_steps
    if alg == 'gpytorch':
        gap = T * math.ceil(n / bs) / save_steps
    steps = gap * np.arange(save_steps + 1)
    if alg == 'falkon':
        M = 10000
        starttime = time.time()
        beta, indices, falkon_mse = FALKON(X, y, None, M, K, 0, T, save_steps=save_steps, save_KXX=save_KXX, kernel='nngp')
        endtime = time.time()
        alg_time = endtime - starttime
        print('falkon time', alg_time)
        print('generating MSE')
        # mse = generate_mse(falkon_mse, K, X, y, indices=indices)
        # print('generating classification error')
        # class_err = generate_mse(falkon_mse, K, X, y, indices=indices, loss='class')
        mse, class_err = generate_mse(falkon_mse, K, X, y, indices=indices, loss='both', save_KXX=save_KXX)
        model = [beta]
        test_mse, test_class_err = generate_mse_test(model, K, X, X_test, y_test, indices=indices, loss='both', save_KXX=save_KXX)
        test_mse_all, test_class_err_all = generate_mse_test(falkon_mse, K, X, X_test, y_test, indices=indices, loss='both', save_KXX=save_KXX)

    elif alg == 'eigenpro':
        starttime = time.time()
        a, MSE_Eigenpro, Eigenpro_param_error = eigenpro(K, X, y, q, T, m=bs, error=True, nystrom=nystrom,
                                                            save_steps=save_steps, save_KXX=save_KXX)
        
        endtime = time.time()
        model = [a]
        alg_time = endtime - starttime
        print('eigenpro_time', alg_time)
        print('generating MSE_Eigenpro')
        # mse = generate_mse(MSE_Eigenpro, K, X, y)
        # print('generating classification error')
        # class_err = generate_mse(MSE_Eigenpro, K, X, y, loss='class')
        mse, class_err = generate_mse(MSE_Eigenpro, K, X, y, loss='both', save_KXX=save_KXX)
        print('X_test.shape', X_test.shape)
        test_mse, test_class_err = generate_mse_test(model, K, X, X_test, y_test, loss='both', save_KXX=save_KXX)
        print('test_class_err=', test_class_err)
        test_mse_all, test_class_err_all = generate_mse_test(MSE_Eigenpro, K, X, X_test, y_test, loss='both', save_KXX=save_KXX)
        print('test_class_err_all=', test_class_err_all)
    elif alg ==  'cg':
        starttime = time.time()
        a, CG_MSE = conjugate_gradient(K, X, y, epochs=T, save_steps=save_steps, save_KXX=save_KXX)
        endtime = time.time()
        alg_time = endtime - starttime
        print('cg_time', alg_time)
        print('generating CG_MSE')
        model = [a]
        # mse = generate_mse(CG_MSE, K, X, y)
        # print('generating classification error')
        # class_err = generate_mse(CG_MSE, K, X, y, loss='class')
        mse, class_err = generate_mse(CG_MSE, K, X, y, loss='both',save_KXX=save_KXX)
        test_mse, test_class_err = generate_mse_test(model, K, X, X_test, y_test, loss='both', save_KXX=save_KXX)
        test_mse_all, test_class_err_all = generate_mse_test(CG_MSE, K, X, X_test, y_test, loss='both', save_KXX=save_KXX)
        print('test_class_err_all=', test_class_err_all)

    elif alg ==  'pmass':
        setup_time = [0, 0]
        nids = torch.randperm(n)[:nystrom]
        KXX_nystrom = K[nids][:, nids]
        starttime = time.time()
        #_ = torch.lobpcg(KXX_nystrom, q + 1)
        L, E = scipy.linalg.eigh(KXX_nystrom.cpu().numpy(), subset_by_index=[nystrom-q-1,nystrom-1])
        endtime = time.time()
        setup_time[0] = endtime - starttime

        print('setup_time(largest eigen)', setup_time[0])

        starttime = time.time()
        #_ = torch.lobpcg(KXX_nystrom, 1, largest=False)
        _ = scipy.linalg.eigh(KXX_nystrom.cpu().numpy(), eigvals_only=True, eigvals=(0, 0))
        endtime = time.time()
        setup_time[1] = endtime - starttime
        print('setup_time(smallest eigen)', setup_time[1])
        starttime = time.time()
        a, MSE_Pmass, Pmass_param_error = PKmass_test(K, X, y, T, bs, q, nystrom=nystrom, save_steps=save_steps, save_KXX=save_KXX)
        endtime = time.time()
        alg_time = endtime - starttime
        model = [a]
        print('Pmass_time', alg_time)
        print('generating MSE_Pmass')
        # mse = generate_mse(MSE_Pmass, K, X, y)
        # print('generating classification error')
        # class_err = generate_mse(MSE_Pmass, K, X, y, loss='class')
        mse, class_err = generate_mse(MSE_Pmass, K, X, y, loss='both', save_KXX=save_KXX)
        test_mse, test_class_err = generate_mse_test(model, K, X, X_test, y_test, loss='both', save_KXX=save_KXX)
        test_mse_all, test_class_err_all = generate_mse_test(MSE_Pmass, K, X, X_test, y_test, loss='both', save_KXX=save_KXX)

    elif alg ==  'pcg':
        starttime = time.time()
        # ker_operator = KernelLinearOperator(
        #     X, X, covar_func=gaussian_ker, num_nonbatch_dimensions={"outputscale": 0}
        # )
        ker_operator = to_linear_operator(K)
        # ker_operator = KernelLinearOperator(
        #     X, X,  # lengthscale=lengthscale, outputscale=outputscale,
        #     covar_func=gaussian_ker, num_nonbatch_dimensions={"outputscale": 0}
        # )

        sigma = 1
        k = 2000
        # KXX=KKK(X,X)
        L = gpytorch.pivoted_cholesky(ker_operator, k, error_tol=None, return_pivots=False)
        endtime = time.time()
        setup_time = endtime - starttime
        print('setup_time for pcg', setup_time)

        starttime = time.time()
        a, pcg_mse = precond_conjugate_gradient(K, X, y, L, sigma, epochs=T, save_steps=save_steps, save_KXX=save_KXX)

        endtime = time.time()
        alg_time = endtime - starttime
        print('pcg_time', alg_time)
        print('generating pcg mse')
        model = [a]
        # mse = generate_mse(pcg_mse, K, X, y)
        # print(mse)
        # print('generating classification error')
        # class_err = generate_mse(pcg_mse, K, X, y, loss='class')
        mse, class_err = generate_mse(pcg_mse, K, X, y, loss='both', save_KXX=save_KXX)
        print(X_test.dtype)
        test_mse, test_class_err = generate_mse_test(model, K, X, X_test, y_test, loss='both', save_KXX=save_KXX)
        test_mse_all, test_class_err_all = generate_mse_test(pcg_mse, K, X, X_test, y_test, loss='both', save_KXX=save_KXX)

    elif alg ==  'gpytorch':
        starttime = time.time()
        preds, model, likelihood = gpytorch_test(None, X, y, T, bs=bs, num_inducing_points=num_inducing_points,
                                                    save_steps=save_steps)

        endtime = time.time()
        alg_time = endtime - starttime

        starttime = time.time()
        model.eval()
        likelihood.eval()
        batch_predictions = likelihood(model(X[:1000, :]))
        pred = batch_predictions.mean
        _ = (pred - y[:1000, :]).pow(2).mean()
        endtime = time.time()
        setup_time = save_steps * (n / 1000) * (endtime - starttime)

        print('gpytorch', alg_time)
        print('generating gpytorch loss')
        mse, class_err = gpytorch_mse(preds, y, loss='both')
        batch_predictions = likelihood(model(X_test))
        pred = batch_predictions.mean
        print(pred)
        test_mse, test_class_err = gpytorch_mse([pred], y_test, loss='both')
        # print('generating classification error')
        # class_err = gpytorch_mse(preds, y, loss='class')
    elif alg ==  'gpflow':
        pass
    print('mse=', mse)
    print('class_err=', class_err)
    return steps, alg_time, setup_time, mse, class_err, test_mse, test_class_err,test_mse_all, test_class_err_all


DEV = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

DATADIR = 'cifar-10-batches-py'

dataloader = Load_Data(DATADIR)

X, y = dataloader.loader(DATADIR)
KXX = np.load('NTK.npy')
KXX = torch.from_numpy(KXX)
KXX_test = KXX[50000: ,:50000]
KXX = KXX[:50000, :50000]
print('KXX.shape=', KXX.shape)
print('KXX_test.shape=', KXX_test.shape)

X_test, y_test = dataloader.loader(DATADIR, test=True)
n = X.shape[0]
y = y.to(DEV)
y_test = y_test.to(DEV)
KXX = KXX.to(DEV)
KXX_test = KXX_test.to(DEV)
KXX = KXX.double()
KXX_test = KXX_test.double()
X=X.to(DEV)
print('moved to device')
X = X.double()
X_test = X_test.double()
y = y.double()
y_test = y_test.double()
#Kmat = K(X, X)
# mean = X.mean(dim=0)
# std = X.std(dim=0)

# Perform the normalization
#normalize X and X_test


# X = (X - mean)*0.001 #X/X.norm(dim=-1, keepdim=True)
# X_test = (X_test - mean)*0.001#/X_test.norm(dim=-1, keepdim=True)


print(X.device)
# print('shape of X is', X.shape)
# print('shape of y is', y.shape)
# print('shape of X_test is', X_test.shape)
print('shape of y_test is', y_test.shape)
bs = 2000

# alg = 'falkon'
# T = 20
# #
# alg = 'cg'
# T = 1200

# alg = 'pcg'
# T = 300

# alg = 'eigenpro'
# T = 6000

alg = 'pmass'
T = 6000

# alg = 'gpytorch'
# T = 1
# bs=1000
steps, time, setup_time, MSE, class_err, test_mse, test_class_err ,test_mse_all, test_class_err_all= run_example(alg, X, y, KXX_test, y_test, KXX, T, bs=bs, q=300, nystrom=10000,
                                                     num_inducing_points=1000)
print('test_mse, test_class_err:', test_mse, test_class_err)
print('test_class_err_all:', test_class_err_all)
data_saver = Save_Data(DATADIR)
dict = data_saver.dict_generator(steps, time, setup_time, MSE, class_err, test_mse, test_class_err, test_mse_all, test_class_err_all)
data_saver.save_data(alg, dict)