import random
import tqdm
import math
import torch
import gpytorch
from tqdm.auto import tqdm
from torch.utils.data import TensorDataset, DataLoader
from gpytorch.functions import RBFCovariance
from gpytorch.settings import trace_mode
from gpytorch.kernels.kernel import Kernel

def postprocess_rbf(dist_mat):
    return dist_mat.div_(-1).exp_()

class LaplacianKernel(Kernel):

    has_lengthscale = True

    def forward(self, x1, x2, diag=False, **params):
        if (
            x1.requires_grad
            or x2.requires_grad
            or (self.ard_num_dims is not None and self.ard_num_dims > 1)
            or diag
            or params.get("last_dim_is_batch", False)
            or trace_mode.on()
        ):
            x1_ = x1.div(self.lengthscale)
            x2_ = x2.div(self.lengthscale)
            return postprocess_rbf(self.covar_dist(x1_, x2_, square_dist=True, diag=diag, **params).pow_(0.5))
        return RBFCovariance.apply(
            x1,
            x2,
            self.lengthscale,
            lambda x1, x2: self.covar_dist(x1, x2, square_dist=True, diag=False, **params),
        )


def gpytorch_mse(preds, y, loss='mse'):
    save_steps = len(preds)
    mse = torch.zeros(save_steps)
    i=0
    if loss=='mse':
        for pred in preds:
            mse[i] = (pred - y).pow(2).mean()
            i+=1
    elif loss=='class':
        true_label = torch.argmax(y, dim=1)
        for pred in preds:
            max_indices = torch.argmax(pred, dim=1)
            zero_mask = (abs(max_indices - true_label) == 0)
            num_zeros = torch.sum(zero_mask).item()
            mse[i] = num_zeros / y.shape[0]
            i += 1
    elif loss=='both':
        class_err = torch.zeros(save_steps)
        true_label = torch.argmax(y, dim=1)
        for pred in preds:
            if y.shape[1] == 1:
                pred_label = (pred >= 0.5).int()
                num_wrong = torch.sum(abs(pred_label - y))
                class_err[i] = 1 - (num_wrong / y.shape[0])
            else:
                max_indices = torch.argmax(pred, dim=1)
                zero_mask = (abs(max_indices - true_label) == 0)
                num_zeros = torch.sum(zero_mask).item()
                class_err[i] = num_zeros / y.shape[0]
            mse[i] = (pred - y).pow(2).mean()
            i += 1
        #print('correct labels, total', num_zeros, y.shape[0])
        return mse, class_err

    return mse

class IndependentMultitaskGPModel(gpytorch.models.ApproximateGP):
    def __init__(self, inducing_points=None, num_tasks=4):
        # Let's use a different set of inducing points for each task
        if inducing_points == None:
            inducing_points = torch.rand(3, 16, 1)

        # We have to mark the CholeskyVariationalDistribution as batch
        # so that we learn a variational distribution for each task
        variational_distribution = gpytorch.variational.CholeskyVariationalDistribution(
            inducing_points.size(-2), batch_shape=torch.Size([num_tasks])
        )

        variational_strategy = gpytorch.variational.IndependentMultitaskVariationalStrategy(
            gpytorch.variational.VariationalStrategy(
                self, inducing_points, variational_distribution, learn_inducing_locations=True
            ),
            num_tasks=num_tasks,
        )

        super().__init__(variational_strategy)

        # The mean and covariance modules should be marked as batch
        # so we learn a different set of hyperparameters
        self.mean_module = gpytorch.means.ConstantMean(batch_shape=torch.Size([num_tasks]))
        self.covar_module = gpytorch.kernels.ScaleKernel(
            gpytorch.kernels.RBFKernel(batch_shape=torch.Size([num_tasks])),
            batch_shape=torch.Size([num_tasks])
        )

    def forward(self, x):
        # The forward function should be written as if we were dealing with each output
        # dimension in batch
        mean_x = self.mean_module(x)
        covar_x = self.covar_module(x)
        return gpytorch.distributions.MultivariateNormal(mean_x, covar_x)



def gpytorch_test(K, train_x, train_y, T, bs=2048, num_inducing_points=20000, save_steps=100):
    n = train_x.shape[0]
    num_tasks = train_y.shape[1]
    myList = list(range(0, n))
    bids = sorted(random.sample(myList, k=num_inducing_points))
    model = IndependentMultitaskGPModel(inducing_points=train_x[bids, :], num_tasks=num_tasks)
    model.to('cuda')
    train_dataset = TensorDataset(train_x, train_y)
    train_loader = DataLoader(train_dataset, batch_size=bs, shuffle=True)
    likelihood = gpytorch.likelihoods.MultitaskGaussianLikelihood(num_tasks=num_tasks)
    likelihood.to('cuda')
    num_epochs = T
    model.train()
    likelihood.train()
    optimizer = torch.optim.Adam([
        {'params': model.parameters()},
        {'params': likelihood.parameters()},
    ], lr=0.05)
    mll = gpytorch.mlls.VariationalELBO(likelihood, model, num_data=train_y.size(0))
    epochs_iter = tqdm(range(num_epochs), desc="Epoch")
    preds = [0] * (save_steps + 1)
    preds[0] = torch.zeros_like(train_y, device=train_y.device)
    save_count = 0
    t=0
    for i in epochs_iter:
        minibatch_iter = tqdm(train_loader, desc="Minibatch", leave=False)
        for x_batch, y_batch in minibatch_iter:
            optimizer.zero_grad()
            output = model(x_batch)
            loss = -mll(output, y_batch)
            epochs_iter.set_postfix(loss=loss.item())
            loss.backward()
            optimizer.step()
            t = t+1
            if (t + 1) % int(math.ceil(n/bs)*T / save_steps) == 0 and save_count < save_steps:
                save_count += 1
                with torch.no_grad(), gpytorch.settings.fast_pred_var():
                    model.eval()
                    likelihood.eval()
                    predictions = torch.zeros_like(train_y, device=train_y.device)
                    preds[save_count] = predictions
                    for j in range(math.ceil(n/1000)):
                        batch_predictions = likelihood(model(train_x[j*1000: min((j+1)*1000, n), :]))
                        preds[save_count][j*1000: min((j+1)*1000, n), :] = batch_predictions.mean
                model.train()
                likelihood.train()
    return preds, model, likelihood

'''
train_x=torch.rand(1000,5)
train_y = torch.rand(1000, 4)
train_y=train_y.to('cuda')
train_x=train_x.to('cuda')
preds, model, likelihood = gpytorch_test(None, train_x, train_y, 10, bs=20, num_inducing_points=500)
'''